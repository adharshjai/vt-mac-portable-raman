cmake_minimum_required(VERSION 3.16)

project(laser_test VERSION 0.1 LANGUAGES CXX)

set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTORCC ON)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# The macOS deploy folder is flat (handshake_v2/, scan_sessions/ next to the executable),
# so the controller is built as a plain executable there. Default keeps the .app bundle.
option(RAMAN_FLAT_LAYOUT "Build a plain executable instead of an .app bundle" OFF)

# -------------Add Charts here---------------
find_package(QT NAMES Qt6 Qt5 REQUIRED COMPONENTS Widgets Charts)
find_package(Qt${QT_VERSION_MAJOR} REQUIRED COMPONENTS Widgets Charts)
# ----------------------------------------

# main.cpp includes the four display headers (window_theme.h, window_status.h, data_layer_client.h,
# data_panels.h), and data_panels.h includes arc_panel.h, the uploads to ARC of the Data tab. They
# hold no Q_OBJECT class, so they need no moc step and the test programs that include main.cpp build
# as before; they are listed here so that Qt Creator shows them. No header of this folder may be named
# ui_<name>.h: AUTOUIC takes such an include for the output of <name>.ui.
set(PROJECT_SOURCES
        main.cpp
        acquisition_protocol.h
        window_theme.h
        window_status.h
        data_layer_client.h
        data_panels.h
        arc_panel.h
        mainwindow.cpp
        mainwindow.h
        mainwindow.ui
)

if(${QT_VERSION_MAJOR} GREATER_EQUAL 6)
    qt_add_executable(laser_test
        MANUAL_FINALIZATION
        ${PROJECT_SOURCES}
    )
else()
    if(ANDROID)
        add_library(laser_test SHARED
            ${PROJECT_SOURCES}
        )
    else()
        add_executable(laser_test
            ${PROJECT_SOURCES}
        )
    endif()
endif()

# -------------Add Charts here---------------
target_link_libraries(laser_test PRIVATE Qt${QT_VERSION_MAJOR}::Widgets Qt${QT_VERSION_MAJOR}::Charts)
# ----------------------------------------

if(${QT_VERSION} VERSION_LESS 6.1.0)
  set(BUNDLE_ID_OPTION MACOSX_BUNDLE_GUI_IDENTIFIER com.example.laser_test)
endif()
set_target_properties(laser_test PROPERTIES
    ${BUNDLE_ID_OPTION}
    MACOSX_BUNDLE_BUNDLE_VERSION ${PROJECT_VERSION}
    MACOSX_BUNDLE_SHORT_VERSION_STRING ${PROJECT_VERSION_MAJOR}.${PROJECT_VERSION_MINOR}
    MACOSX_BUNDLE TRUE
    WIN32_EXECUTABLE TRUE
)
if(RAMAN_FLAT_LAYOUT)
    set_target_properties(laser_test PROPERTIES MACOSX_BUNDLE FALSE)
endif()

# macOS: a build started outside the deploy folder (Qt Creator's build directory, an .app bundle)
# falls back to ../deploy-macos, assembled by macos-native/build_macos.sh, for its helper programs
# and data folders (ramanHome() in main.cpp). Override with -DRAMAN_DEFAULT_HOME=<folder>.
if(APPLE)
    get_filename_component(RAMAN_DEPLOY_MACOS "${CMAKE_CURRENT_SOURCE_DIR}/../deploy-macos" ABSOLUTE)
    set(RAMAN_DEFAULT_HOME "${RAMAN_DEPLOY_MACOS}" CACHE PATH "Deploy folder used when handshake_v2/ is not next to the executable")
    target_compile_definitions(laser_test PRIVATE "RAMAN_DEFAULT_HOME=\"${RAMAN_DEFAULT_HOME}\"")
endif()

include(GNUInstallDirs)
install(TARGETS laser_test
    BUNDLE DESTINATION .
    LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
    RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
)

if(QT_VERSION_MAJOR EQUAL 6)
    qt_finalize_executable(laser_test)
endif()
