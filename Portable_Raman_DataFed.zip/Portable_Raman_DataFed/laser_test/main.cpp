#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QElapsedTimer>
#include <QThread>
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>
#include <QTimer>
#include <QProcess>
#include <QLabel>
#include <QDateTime>
#include <QDialog>
#include <QChartView>
#include <QLineSeries>
#include <QValueAxis>
#include <QFileInfo>
#include <QDir>
#include <QComboBox>
#include <QMouseEvent>
#include <QToolTip>
#include <QStatusBar>
#include <QRegularExpression>
#include <QScopedValueRollback>
#include <QUuid>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QCloseEvent>
#include <QLockFile>
#include <QMessageBox>
#include <QLineEdit>
#include <QSettings>
#include <QScopeGuard>
#include <QStringDecoder>
#include <QGridLayout>
#include <QScrollArea>
#include <QScreen>
#include <QScrollBar>
#include <QShowEvent>
#include <QSplitter>
#include <QTabWidget>
#include <QTextBlock>
#include <QValidator>
#include <QWindow>
#include "acquisition_protocol.h"

#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>

#include <algorithm>
#include <climits>
#include <cstring>
#include <memory>
#include <optional>

// Folder that holds handshake_v2/, cnn_1.py and the data (scan_sessions/, dark_measurements/,
// laser_log.txt, controller.lock). On Windows, and whenever handshake_v2/ sits next to the
// executable (the deployed layouts and the test builds), it is the executable's own folder, exactly
// as before. A macOS build started from somewhere else - Qt Creator's build directory, an .app
// bundle - uses the deploy folder instead: the RAMAN_HOME environment variable if it names one,
// else the folder recorded at configure time (RAMAN_DEFAULT_HOME, laser_test/CMakeLists.txt).
static QString ramanHome() {
#ifdef Q_OS_WIN
    return QCoreApplication::applicationDirPath();
#else
    static const QString home = [] {
        const auto usable = [](const QString& dir) { return !dir.isEmpty() && QFileInfo(dir + "/handshake_v2").isDir(); };
        const QString appDir = QCoreApplication::applicationDirPath();
        if (usable(appDir)) return appDir;
        const QString fromEnvironment = qEnvironmentVariable("RAMAN_HOME");
        if (usable(fromEnvironment)) return QDir(fromEnvironment).absolutePath();
#ifdef RAMAN_DEFAULT_HOME
        const QString recorded = QString::fromUtf8(RAMAN_DEFAULT_HOME);
        if (usable(recorded)) return QDir(recorded).absolutePath();
#endif
        return appDir;
    }();
    return home;
#endif
}

#ifndef Q_OS_WIN
// Interpreter for "Analyze Latest" outside Windows: RAMAN_PYTHON when set and non-empty (the
// run_*.sh scripts set it; QProcess::start("") could never launch anything, so empty counts as
// unset); else the interpreter recorded by macos-native/build_macos.sh in <home>/raman_python.txt,
// so that a launch from Qt Creator or Finder, whose PATH has neither Anaconda nor Homebrew, still
// uses the Python that has the analysis packages; else python3 from PATH.
static QString ramanAnalysisPython() {
    if (!qEnvironmentVariableIsEmpty("RAMAN_PYTHON")) return qEnvironmentVariable("RAMAN_PYTHON");
    QFile recorded(ramanHome() + "/raman_python.txt");
    if (recorded.open(QIODevice::ReadOnly | QIODevice::Text)) {
        const QString path = QString::fromUtf8(recorded.readLine()).trimmed();
        if (!path.isEmpty() && QFileInfo(path).isExecutable()) return path;
    }
    return QStringLiteral("python3");
}
#endif

static QString kPythonScriptPathValue() { return ramanHome() + "/cnn_1.py"; }
#define kPythonScriptPath kPythonScriptPathValue()

// Name and version this edition records in session.json and in every saved point
// (data_layer/PROTOCOL.md section 2).
static const char kSoftwareName[] = "portable-raman-controller-datafed";
static const char kSoftwareVersion[] = "1.0.0";

// The "simulated" labels (data_layer/PROTOCOL.md section 2.2) apply the rule by which each helper
// program of macos-native/ decides for itself whether it simulates, to the environment it is
// started with. Data is then never labelled simulated while an instrument is driven, nor real while
// a simulator ran. They select nothing.
static QProcessEnvironment startEnvironment(const QProcess* helper) {
    const QProcessEnvironment set = helper->processEnvironment();
    return set.inheritsFromParent() ? QProcessEnvironment::systemEnvironment() : set;
}

// Only the helper programs of macos-native/ have simulators. A Windows build starts the original
// SampleApl.exe and RamanAutofocus.exe of the hand-off folder, which read neither variable and always
// drive the instruments, so nothing there is ever simulated, whatever the window's environment says.
#ifdef Q_OS_WIN
static constexpr bool kHelpersHaveSimulators = false;
#else
static constexpr bool kHelpersHaveSimulators = true;
#endif

// The capture backend (backend/SampleApl/Program.cs) simulates for exactly "1".
static bool backendSimulates(const QProcessEnvironment& environment) {
    return kHelpersHaveSimulators && environment.value("RAMAN_BACKEND_SIMULATE") == "1";
}

// Python's str.strip(): the blanks of QChar::isSpace() and the separators U+001C to U+001F.
static QString strippedLikePython(const QString& text) {
    const auto blank = [](QChar c) { return c.isSpace() || (c.unicode() >= 0x1c && c.unicode() <= 0x1f); };
    qsizetype first = 0, end = text.size();
    while (first < end && blank(text[first])) ++first;
    while (end > first && blank(text[end - 1])) --end;
    return text.mid(first, end - first);
}

// What Python's json module refuses and Qt's parser takes: a raw control character inside a string,
// an escape that JSON does not have ("\q", "\x41", "\'", which Qt reads as the character itself), and
// a number whose point lacks a digit on either side ("1.", ".5", "-.5", "1.e5"). Outside a string a
// point stands only in a number.
static bool refusedOnlyByPython(const QString& json) {
    const auto digit = [&json](qsizetype i) { return i >= 0 && i < json.size() && json[i].unicode() >= u'0' && json[i].unicode() <= u'9'; };
    bool inString = false;
    for (qsizetype i = 0; i < json.size(); ++i) {
        const char16_t c = json[i].unicode();
        if (!inString) {
            if (c == u'"') inString = true;
            else if (c == u'.' && !(digit(i - 1) && digit(i + 1))) return true;
        } else if (c == u'\\') {
            if (i + 1 == json.size() || !QStringView(u"\"\\/bfnrtu").contains(json[i + 1])) return true;
            ++i;
        } else if (c == u'"') inString = false;
        else if (c < 0x20) return true;
    }
    return false;
}

// The JSON object in a file as Python's json module reads it, or nothing: also when Python would
// refuse a file that Qt's parser takes, one that is not UTF-8, starts with a byte order mark, or holds
// what refusedOnlyByPython() finds. The data layer reads the same files with Python.
static std::optional<QJsonObject> jsonObjectLikePython(const QString& path) {
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) return std::nullopt;
    const QByteArray bytes = file.readAll();
    QStringDecoder utf8(QStringDecoder::Utf8);
    const QString text = utf8(bytes);
    if (file.error() != QFileDevice::NoError || utf8.hasError() || bytes.startsWith("\xEF\xBB\xBF") || refusedOnlyByPython(text))
        return std::nullopt;
    QJsonParseError error;
    const QJsonDocument document = QJsonDocument::fromJson(bytes, &error);
    if (error.error != QJsonParseError::NoError || !document.isObject()) return std::nullopt;
    return document.object();
}

// The motor program (motor/apt_kdc101.py select_transport, motor/raman_autofocus.py load_config)
// simulates for RAMAN_MOTOR_SIMULATE "1" once stripped of blanks, else when its motor_config.json
// (RAMAN_MOTOR_CONFIG, relative to its folder, else the file in its folder) selects the transport
// "simulate". A file Python cannot read leaves it on its built-in real transport.
static bool motorSimulates(const QProcessEnvironment& environment, const QString& motorDir) {
    if (!kHelpersHaveSimulators) return false;
    if (strippedLikePython(environment.value("RAMAN_MOTOR_SIMULATE")) == "1") return true;
    const QString configured = environment.value("RAMAN_MOTOR_CONFIG");
    const auto config = jsonObjectLikePython(QDir(motorDir).filePath(configured.isEmpty() ? QStringLiteral("motor_config.json") : configured));
    if (!config) return false;
    const QJsonValue transport = config->value("transport");
    return transport.isBool() ? transport.toBool() : strippedLikePython(transport.toString()).toLower() == "simulate";
}

// The kind of a dark spectrum (lead decision D1), told by dark_<stamp>.json beside dark_<stamp>.txt.
// A dark without one is real: every dark taken before this edition, the hand-off darks included. A
// .json that cannot be read, or that does not say whether the backend simulated, leaves the kind
// unknown, and a dark of unknown kind is paired with nothing.
enum class DarkKind { Real, Simulated, Unknown };
static QString darkRecordPath(const QString& darkTxt) { return darkTxt.chopped(4) + ".json"; }
static DarkKind darkKind(const QString& darkTxt) {
    const QString record = darkRecordPath(darkTxt);
    const QFileInfo found(record);
    if (!found.exists() && !found.isSymLink()) return DarkKind::Real;   // a link to nothing is a .json that cannot be read
    const auto object = jsonObjectLikePython(record);
    const QJsonValue backend = object ? object->value("simulated").toObject().value("backend") : QJsonValue();
    if (!backend.isBool()) return DarkKind::Unknown;
    return backend.toBool() ? DarkKind::Simulated : DarkKind::Real;
}

// An edition that lives inside the original project (<home>/../../deploy-macos is then the
// original's deploy folder) must never run while the original controller does: both would drive
// the same instruments. The original checks nothing but its own controller.lock, so holding that
// file keeps it from starting while this edition runs, and a running original keeps this edition out.
class OriginalControllerLock {
public:
    // False when the lock is not held: error() says whether the original controller holds it
    // (LockFailedError) or the file cannot be created. True with nothing held when this folder is
    // not inside the original project.
    bool acquire(const QString& home) {
        const QString originalHome = QFileInfo(home + "/../../deploy-macos").canonicalFilePath();
        if (originalHome.isEmpty() || originalHome == QFileInfo(home).canonicalFilePath() ||
            !QFileInfo(originalHome + "/handshake_v2").isDir()) return true;
        path = originalHome + "/controller.lock";
        auto candidate = std::make_unique<QLockFile>(path);
        if (!candidate->tryLock(100)) { failure = candidate->error(); return false; }
        failure = QLockFile::NoError;
        lock = std::move(candidate);
        return true;
    }
    QLockFile::LockError error() const { return failure; }
    QString filePath() const { return path; }
private:
    std::unique_ptr<QLockFile> lock;
    QLockFile::LockError failure = QLockFile::NoError;
    QString path;
};

// What main() says when it cannot take a controller.lock: this controller's own (original false) or
// the original controller's. Only LockFailedError means that another controller holds the file. Any
// other error means the file cannot be created, which says nothing about a running controller; the
// start is refused all the same, since the lock could then not keep the other controller out.
struct LockRefusal { QString title, text; };
static LockRefusal lockRefusal(bool original, QLockFile::LockError error, const QString& lockPath) {
    if (error == QLockFile::LockFailedError)
        return original ? LockRefusal{"Original controller running", "The original Raman controller is running and drives the same "
                                                                     "instruments. Close it before starting this edition."}
                        : LockRefusal{"Controller already running", "Close the other Raman controller before starting this one."};
    const QString reason = error == QLockFile::PermissionError ? "no permission to create it" : "it could not be written";
    const QString consequence = original ? "this edition cannot keep the original controller closed while it runs."
                                         : "this controller cannot keep a second one from driving the same instruments.";
    return {original ? "Original controller lock not available" : "Controller lock not available",
            QString("Cannot create %1 (%2): %3").arg(QDir::toNativeSeparators(lockPath), reason, consequence)};
}

// The window's look, its status display and the Data and Review tabs: display code only, in
// headers without Q_OBJECT so that the programs that include this file need no further moc step.
#include "window_theme.h"
#include "window_status.h"
#include "data_panels.h"

// The badge next to the program name. Where the helper programs have no simulator (Windows) it never
// says SIMULATION: a simulation variable set there changes nothing, and the operator who set it
// expects a simulation, so the badge says that the instruments are real.
static PillState simulationHeaderBadge(bool helpersHaveSimulators) {
    if (helpersHaveSimulators) return simulationBadge(simulationUse("RAMAN_BACKEND_SIMULATE"), simulationUse("RAMAN_MOTOR_SIMULATE"));
    if (!qEnvironmentVariableIsSet("RAMAN_BACKEND_SIMULATE") && !qEnvironmentVariableIsSet("RAMAN_MOTOR_SIMULATE")) return {};
    return {UiTone::Danger, "NO SIMULATOR ON WINDOWS: instruments are real",
            "RAMAN_BACKEND_SIMULATE or RAMAN_MOTOR_SIMULATE is set, but the helper programs of this build (SampleApl.exe, "
            "RamanAutofocus.exe) have no simulator and never read them: the laser and the stages are driven.", true};
}

// The note in the Capture group's title row on the dark that a scan or single capture started now is
// paired with (MainWindow::darkForNextCapture, lead decision D1): its kind and when it was taken, or,
// as a warning, that there is none of the kind the capture backend gives. The classifier rejects every
// spectrum that has no dark.
static PillState nextDarkCaption(const QJsonValue& dark, bool simulated, const QDate& today) {
    const QString kind = simulated ? "simulated" : "real";
    if (!dark.isString())
        return {UiTone::Warn, QString("no %1 dark yet").arg(kind),
                QString("A scan or single capture started now has no dark spectrum, and the classifier rejects spectra without one. "
                        "Block the optical path and press Capture Dark first: %1 spectra are paired with a %1 dark only.").arg(kind)};
    const QString name = dark.toString();
    const QDateTime taken = QDateTime::fromString(name.mid(5, 15), "yyyyMMdd_HHmmss");   // dark_yyyyMMdd_HHmmss_zzz.txt
    const QString text = !taken.isValid() ? QString("%1 dark %2").arg(kind, name)
                       : QString("%1 dark of %2").arg(kind, taken.toString(taken.date() == today ? "HH:mm:ss" : "d MMM HH:mm"));
    return {UiTone::Neutral, text,
            QString("A scan or single capture started now is paired with dark_measurements/%1, the newest %2 dark. "
                    "Capture Dark takes a new one.").arg(name, kind)};
}

// The Sample group's fields hold at most 200 UTF-16 units, and QLineEdit cuts a text at its limit
// wherever the limit falls, also between the two halves of a character outside the Basic Multilingual
// Plane (an emoji): a remembered value that is too long, a paste across the limit, such a character
// typed with one unit of room left. Half a character would reach session.json and every point as
// \ud83d, text the data layer cannot store. Every change of a field's text passes this validator, which
// leaves each half character out, so the fields only ever hold whole characters.
class WholeCharacterValidator : public QValidator {
public:
    using QValidator::QValidator;
    State validate(QString& input, int& pos) const override {
        for (qsizetype i = 0; i < input.size();) {
            if (input[i].isHighSurrogate() && i + 1 < input.size() && input[i + 1].isLowSurrogate()) i += 2;
            else if (!input[i].isSurrogate()) ++i;
            else {
                input.remove(i, 1);
                if (pos > i) --pos;
            }
        }
        return Acceptable;
    }
};

namespace {
static const int kNumPixels = 2048;
static const double kRamanShift[kNumPixels] = {
    57.42448267,
    60.29131328,
    63.15612404,
    66.01891664,
    68.87969276,
    71.73845411,
    74.59520236,
    77.44993921,
    80.30266633,
    83.15338541,
    86.00209813,
    88.84880617,
    91.6935112,
    94.53621489,
    97.37691893,
    100.215625,
    103.0523347,
    105.8870498,
    108.7197719,
    111.5505026,
    114.3792437,
    117.2059968,
    120.0307636,
    122.8535457,
    125.6743447,
    128.4931623,
    131.3100002,
    134.1248601,
    136.9377435,
    139.7486521,
    142.5575875,
    145.3645515,
    148.1695455,
    150.9725714,
    153.7736306,
    156.5727249,
    159.3698559,
    162.1650252,
    164.9582344,
    167.7494851,
    170.5387791,
    173.3261178,
    176.111503,
    178.8949363,
    181.6764192,
    184.4559533,
    187.2335404,
    190.009182,
    192.7828797,
    195.5546352,
    198.32445,
    201.0923257,
    203.8582639,
    206.6222664,
    209.3843345,
    212.1444701,
    214.9026745,
    217.6589495,
    220.4132966,
    223.1657175,
    225.9162137,
    228.6647868,
    231.4114383,
    234.15617,
    236.8989832,
    239.6398798,
    242.3788611,
    245.1159289,
    247.8510846,
    250.5843298,
    253.3156662,
    256.0450953,
    258.7726186,
    261.4982377,
    264.2219542,
    266.9437697,
    269.6636857,
    272.3817038,
    275.0978255,
    277.8120524,
    280.524386,
    283.234828,
    285.9433797,
    288.6500429,
    291.3548191,
    294.0577097,
    296.7587164,
    299.4578407,
    302.1550841,
    304.8504482,
    307.5439344,
    310.2355445,
    312.9252798,
    315.6131419,
    318.2991323,
    320.9832527,
    323.6655044,
    326.3458891,
    329.0244082,
    331.7010633,
    334.3758559,
    337.0487875,
    339.7198596,
    342.3890738,
    345.0564316,
    347.7219345,
    350.3855839,
    353.0473815,
    355.7073287,
    358.365427,
    361.0216779,
    363.676083,
    366.3286437,
    368.9793615,
    371.6282379,
    374.2752745,
    376.9204727,
    379.5638341,
    382.20536,
    384.8450521,
    387.4829117,
    390.1189404,
    392.7531397,
    395.385511,
    398.0160559,
    400.6447758,
    403.2716721,
    405.8967465,
    408.5200003,
    411.141435,
    413.7610521,
    416.3788531,
    418.9948394,
    421.6090125,
    424.2213739,
    426.831925,
    429.4406673,
    432.0476023,
    434.6527314,
    437.2560561,
    439.8575778,
    442.4572981,
    445.0552182,
    447.6513398,
    450.2456643,
    452.838193,
    455.4289275,
    458.0178692,
    460.6050195,
    463.1903799,
    465.7739518,
    468.3557368,
    470.9357361,
    473.5139512,
    476.0903837,
    478.6650348,
    481.2379061,
    483.808999,
    486.3783149,
    488.9458552,
    491.5116214,
    494.0756149,
    496.637837,
    499.1982893,
    501.7569732,
    504.31389,
    506.8690412,
    509.4224283,
    511.9740525,
    514.5239154,
    517.0720183,
    519.6183627,
    522.1629499,
    524.7057814,
    527.2468585,
    529.7861828,
    532.3237555,
    534.8595781,
    537.3936519,
    539.9259785,
    542.4565591,
    544.9853952,
    547.5124881,
    550.0378393,
    552.5614502,
    555.0833221,
    557.6034563,
    560.1218544,
    562.6385177,
    565.1534476,
    567.6666454,
    570.1781125,
    572.6878504,
    575.1958603,
    577.7021437,
    580.206702,
    582.7095365,
    585.2106485,
    587.7100395,
    590.2077108,
    592.7036638,
    595.1978999,
    597.6904204,
    600.1812266,
    602.67032,
    605.1577019,
    607.6433737,
    610.1273367,
    612.6095922,
    615.0901417,
    617.5689865,
    620.0461278,
    622.5215672,
    624.9953059,
    627.4673453,
    629.9376867,
    632.4063314,
    634.8732809,
    637.3385364,
    639.8020993,
    642.2639709,
    644.7241525,
    647.1826456,
    649.6394514,
    652.0945713,
    654.5480066,
    656.9997586,
    659.4498286,
    661.8982181,
    664.3449282,
    666.7899604,
    669.2333159,
    671.6749961,
    674.1150023,
    676.5533358,
    678.9899979,
    681.42499,
    683.8583134,
    686.2899693,
    688.7199592,
    691.1482842,
    693.5749457,
    695.999945,
    698.4232835,
    700.8449624,
    703.264983,
    705.6833467,
    708.1000547,
    710.5151083,
    712.9285088,
    715.3402576,
    717.7503559,
    720.158805,
    722.5656063,
    724.9707609,
    727.3742702,
    729.7761355,
    732.1763581,
    734.5749392,
    736.9718802,
    739.3671822,
    741.7608467,
    744.1528749,
    746.543268,
    748.9320274,
    751.3191543,
    753.70465,
    756.0885158,
    758.4707529,
    760.8513626,
    763.2303462,
    765.6077049,
    767.98344,
    770.3575529,
    772.7300447,
    775.1009167,
    777.4701702,
    779.8378064,
    782.2038266,
    784.568232,
    786.931024,
    789.2922037,
    791.6517725,
    794.0097315,
    796.366082,
    798.7208253,
    801.0739627,
    803.4254953,
    805.7754244,
    808.1237513,
    810.4704772,
    812.8156033,
    815.159131,
    817.5010613,
    819.8413957,
    822.1801352,
    824.5172812,
    826.8528349,
    829.1867974,
    831.5191702,
    833.8499542,
    836.1791509,
    838.5067615,
    840.832787,
    843.1572289,
    845.4800883,
    847.8013664,
    850.1210645,
    852.4391837,
    854.7557254,
    857.0706907,
    859.3840808,
    861.6958969,
    864.0061403,
    866.3148122,
    868.6219138,
    870.9274462,
    873.2314108,
    875.5338087,
    877.8346411,
    880.1339093,
    882.4316144,
    884.7277576,
    887.0223402,
    889.3153633,
    891.6068282,
    893.896736,
    896.1850879,
    898.4718852,
    900.757129,
    903.0408205,
    905.3229609,
    907.6035515,
    909.8825933,
    912.1600876,
    914.4360356,
    916.7104385,
    918.9832974,
    921.2546135,
    923.524388,
    925.7926222,
    928.059317,
    930.3244739,
    932.5880939,
    934.8501782,
    937.1107279,
    939.3697443,
    941.6272286,
    943.8831818,
    946.1376052,
    948.3905,
    950.6418672,
    952.8917082,
    955.1400239,
    957.3868157,
    959.6320847,
    961.875832,
    964.1180587,
    966.3587662,
    968.5979554,
    970.8356276,
    973.0717839,
    975.3064255,
    977.5395536,
    979.7711692,
    982.0012736,
    984.2298678,
    986.4569531,
    988.6825306,
    990.9066014,
    993.1291667,
    995.3502276,
    997.5697853,
    999.7878409,
    1002.004396,
    1004.21945,
    1006.433007,
    1008.645065,
    1010.855627,
    1013.064694,
    1015.272267,
    1017.478347,
    1019.682935,
    1021.886032,
    1024.08764,
    1026.287759,
    1028.486391,
    1030.683537,
    1032.879197,
    1035.073374,
    1037.266068,
    1039.45728,
    1041.647011,
    1043.835263,
    1046.022036,
    1048.207333,
    1050.391153,
    1052.573498,
    1054.754369,
    1056.933768,
    1059.111694,
    1061.288151,
    1063.463137,
    1065.636656,
    1067.808707,
    1069.979292,
    1072.148412,
    1074.316068,
    1076.482261,
    1078.646992,
    1080.810263,
    1082.972075,
    1085.132427,
    1087.291323,
    1089.448762,
    1091.604746,
    1093.759277,
    1095.912354,
    1098.063979,
    1100.214154,
    1102.362878,
    1104.510155,
    1106.655983,
    1108.800366,
    1110.943303,
    1113.084796,
    1115.224845,
    1117.363453,
    1119.500619,
    1121.636346,
    1123.770633,
    1125.903483,
    1128.034896,
    1130.164874,
    1132.293417,
    1134.420527,
    1136.546204,
    1138.67045,
    1140.793265,
    1142.914652,
    1145.03461,
    1147.153141,
    1149.270246,
    1151.385927,
    1153.500183,
    1155.613017,
    1157.724429,
    1159.83442,
    1161.942992,
    1164.050145,
    1166.15588,
    1168.260199,
    1170.363103,
    1172.464592,
    1174.564668,
    1176.663332,
    1178.760585,
    1180.856427,
    1182.950861,
    1185.043886,
    1187.135505,
    1189.225717,
    1191.314525,
    1193.401928,
    1195.487929,
    1197.572528,
    1199.655727,
    1201.737526,
    1203.817926,
    1205.896928,
    1207.974534,
    1210.050744,
    1212.12556,
    1214.198982,
    1216.271012,
    1218.341651,
    1220.410899,
    1222.478758,
    1224.545228,
    1226.610311,
    1228.674008,
    1230.736319,
    1232.797247,
    1234.856791,
    1236.914953,
    1238.971734,
    1241.027134,
    1243.081156,
    1245.1338,
    1247.185066,
    1249.234956,
    1251.283471,
    1253.330613,
    1255.376381,
    1257.420777,
    1259.463802,
    1261.505458,
    1263.545744,
    1265.584662,
    1267.622213,
    1269.658399,
    1271.693219,
    1273.726675,
    1275.758769,
    1277.7895,
    1279.818871,
    1281.846881,
    1283.873533,
    1285.898827,
    1287.922764,
    1289.945344,
    1291.96657,
    1293.986442,
    1296.004961,
    1298.022128,
    1300.037944,
    1302.05241,
    1304.065527,
    1306.077296,
    1308.087718,
    1310.096794,
    1312.104524,
    1314.110911,
    1316.115955,
    1318.119656,
    1320.122017,
    1322.123037,
    1324.122718,
    1326.121061,
    1328.118067,
    1330.113736,
    1332.10807,
    1334.10107,
    1336.092737,
    1338.083071,
    1340.072074,
    1342.059746,
    1344.046089,
    1346.031104,
    1348.014791,
    1349.997152,
    1351.978187,
    1353.957897,
    1355.936284,
    1357.913348,
    1359.889091,
    1361.863513,
    1363.836615,
    1365.808398,
    1367.778863,
    1369.748012,
    1371.715844,
    1373.682362,
    1375.647565,
    1377.611456,
    1379.574034,
    1381.535301,
    1383.495258,
    1385.453906,
    1387.411245,
    1389.367277,
    1391.322003,
    1393.275423,
    1395.227538,
    1397.17835,
    1399.12786,
    1401.076067,
    1403.022974,
    1404.968581,
    1406.912889,
    1408.8559,
    1410.797613,
    1412.73803,
    1414.677153,
    1416.61498,
    1418.551515,
    1420.486758,
    1422.420709,
    1424.353369,
    1426.28474,
    1428.214823,
    1430.143618,
    1432.071126,
    1433.997348,
    1435.922286,
    1437.845939,
    1439.76831,
    1441.689398,
    1443.609205,
    1445.527732,
    1447.44498,
    1449.360949,
    1451.275641,
    1453.189056,
    1455.101196,
    1457.012061,
    1458.921652,
    1460.82997,
    1462.737016,
    1464.642791,
    1466.547296,
    1468.450531,
    1470.352499,
    1472.253199,
    1474.152632,
    1476.0508,
    1477.947703,
    1479.843342,
    1481.737719,
    1483.630833,
    1485.522686,
    1487.413279,
    1489.302613,
    1491.190689,
    1493.077507,
    1494.963068,
    1496.847374,
    1498.730425,
    1500.612222,
    1502.492767,
    1504.372059,
    1506.250099,
    1508.12689,
    1510.002431,
    1511.876724,
    1513.749769,
    1515.621567,
    1517.49212,
    1519.361427,
    1521.229491,
    1523.096311,
    1524.961889,
    1526.826226,
    1528.689322,
    1530.551178,
    1532.411796,
    1534.271176,
    1536.129319,
    1537.986225,
    1539.841897,
    1541.696334,
    1543.549538,
    1545.401509,
    1547.252248,
    1549.101756,
    1550.950035,
    1552.797084,
    1554.642905,
    1556.487499,
    1558.330867,
    1560.173008,
    1562.013925,
    1563.853618,
    1565.692088,
    1567.529336,
    1569.365363,
    1571.200169,
    1573.033756,
    1574.866124,
    1576.697274,
    1578.527207,
    1580.355925,
    1582.183427,
    1584.009714,
    1585.834788,
    1587.658649,
    1589.481299,
    1591.302738,
    1593.122966,
    1594.941985,
    1596.759796,
    1598.5764,
    1600.391796,
    1602.205987,
    1604.018973,
    1605.830755,
    1607.641333,
    1609.450709,
    1611.258884,
    1613.065858,
    1614.871632,
    1616.676206,
    1618.479583,
    1620.281762,
    1622.082745,
    1623.882532,
    1625.681124,
    1627.478523,
    1629.274728,
    1631.06974,
    1632.863562,
    1634.656192,
    1636.447633,
    1638.237885,
    1640.026949,
    1641.814826,
    1643.601516,
    1645.38702,
    1647.17134,
    1648.954475,
    1650.736428,
    1652.517198,
    1654.296787,
    1656.075195,
    1657.852423,
    1659.628472,
    1661.403343,
    1663.177037,
    1664.949554,
    1666.720896,
    1668.491062,
    1670.260055,
    1672.027874,
    1673.794521,
    1675.559997,
    1677.324301,
    1679.087436,
    1680.849401,
    1682.610198,
    1684.369828,
    1686.128291,
    1687.885588,
    1689.64172,
    1691.396687,
    1693.150492,
    1694.903133,
    1696.654613,
    1698.404932,
    1700.15409,
    1701.902089,
    1703.64893,
    1705.394613,
    1707.139139,
    1708.882508,
    1710.624722,
    1712.365782,
    1714.105688,
    1715.844441,
    1717.582042,
    1719.318491,
    1721.05379,
    1722.787939,
    1724.520939,
    1726.252791,
    1727.983496,
    1729.713054,
    1731.441466,
    1733.168733,
    1734.894856,
    1736.619836,
    1738.343673,
    1740.066368,
    1741.787923,
    1743.508337,
    1745.227611,
    1746.945747,
    1748.662745,
    1750.378606,
    1752.093331,
    1753.80692,
    1755.519374,
    1757.230695,
    1758.940882,
    1760.649937,
    1762.35786,
    1764.064653,
    1765.770315,
    1767.474849,
    1769.178253,
    1770.880531,
    1772.581681,
    1774.281705,
    1775.980603,
    1777.678378,
    1779.375028,
    1781.070555,
    1782.76496,
    1784.458244,
    1786.150406,
    1787.841449,
    1789.531373,
    1791.220178,
    1792.907866,
    1794.594437,
    1796.279891,
    1797.964231,
    1799.647455,
    1801.329566,
    1803.010564,
    1804.69045,
    1806.369224,
    1808.046887,
    1809.723441,
    1811.398885,
    1813.073221,
    1814.746449,
    1816.41857,
    1818.089585,
    1819.759494,
    1821.428299,
    1823.096,
    1824.762598,
    1826.428093,
    1828.092487,
    1829.75578,
    1831.417972,
    1833.079065,
    1834.73906,
    1836.397957,
    1838.055757,
    1839.71246,
    1841.368067,
    1843.02258,
    1844.675999,
    1846.328324,
    1847.979556,
    1849.629697,
    1851.278747,
    1852.926706,
    1854.573575,
    1856.219356,
    1857.864048,
    1859.507653,
    1861.150171,
    1862.791603,
    1864.43195,
    1866.071213,
    1867.709391,
    1869.346487,
    1870.982501,
    1872.617433,
    1874.251284,
    1875.884055,
    1877.515747,
    1879.14636,
    1880.775895,
    1882.404353,
    1884.031735,
    1885.658041,
    1887.283273,
    1888.90743,
    1890.530513,
    1892.152524,
    1893.773463,
    1895.39333,
    1897.012127,
    1898.629854,
    1900.246512,
    1901.862101,
    1903.476623,
    1905.090078,
    1906.702467,
    1908.31379,
    1909.924048,
    1911.533243,
    1913.141374,
    1914.748442,
    1916.354448,
    1917.959394,
    1919.563278,
    1921.166104,
    1922.767869,
    1924.368577,
    1925.968227,
    1927.56682,
    1929.164357,
    1930.760839,
    1932.356266,
    1933.950638,
    1935.543958,
    1937.136224,
    1938.727439,
    1940.317603,
    1941.906716,
    1943.494779,
    1945.081794,
    1946.667759,
    1948.252678,
    1949.836549,
    1951.419374,
    1953.001153,
    1954.581888,
    1956.161578,
    1957.740225,
    1959.317829,
    1960.894391,
    1962.469912,
    1964.044392,
    1965.617832,
    1967.190233,
    1968.761596,
    1970.33192,
    1971.901207,
    1973.469458,
    1975.036673,
    1976.602853,
    1978.167999,
    1979.732111,
    1981.29519,
    1982.857236,
    1984.418251,
    1985.978235,
    1987.537189,
    1989.095113,
    1990.652009,
    1992.207876,
    1993.762716,
    1995.316528,
    1996.869315,
    1998.421077,
    1999.971813,
    2001.521526,
    2003.070215,
    2004.617882,
    2006.164526,
    2007.710149,
    2009.254752,
    2010.798334,
    2012.340898,
    2013.882442,
    2015.422969,
    2016.962479,
    2018.500972,
    2020.038449,
    2021.57491,
    2023.110358,
    2024.644791,
    2026.178211,
    2027.710619,
    2029.242015,
    2030.7724,
    2032.301774,
    2033.830138,
    2035.357493,
    2036.88384,
    2038.409179,
    2039.933511,
    2041.456836,
    2042.979156,
    2044.50047,
    2046.02078,
    2047.540086,
    2049.058389,
    2050.575689,
    2052.091988,
    2053.607285,
    2055.121582,
    2056.63488,
    2058.147178,
    2059.658477,
    2061.168779,
    2062.678083,
    2064.186391,
    2065.693703,
    2067.20002,
    2068.705343,
    2070.209671,
    2071.713007,
    2073.215349,
    2074.7167,
    2076.21706,
    2077.716429,
    2079.214808,
    2080.712197,
    2082.208599,
    2083.704012,
    2085.198437,
    2086.691876,
    2088.18433,
    2089.675797,
    2091.16628,
    2092.655779,
    2094.144294,
    2095.631827,
    2097.118377,
    2098.603946,
    2100.088534,
    2101.572142,
    2103.054771,
    2104.53642,
    2106.017091,
    2107.496785,
    2108.975501,
    2110.453242,
    2111.930006,
    2113.405795,
    2114.88061,
    2116.354452,
    2117.82732,
    2119.299215,
    2120.770139,
    2122.240092,
    2123.709074,
    2125.177086,
    2126.644128,
    2128.110202,
    2129.575308,
    2131.039447,
    2132.502618,
    2133.964824,
    2135.426064,
    2136.886339,
    2138.34565,
    2139.803998,
    2141.261382,
    2142.717804,
    2144.173264,
    2145.627763,
    2147.081302,
    2148.533881,
    2149.985501,
    2151.436162,
    2152.885865,
    2154.334611,
    2155.7824,
    2157.229233,
    2158.67511,
    2160.120033,
    2161.564001,
    2163.007016,
    2164.449078,
    2165.890188,
    2167.330346,
    2168.769552,
    2170.207809,
    2171.645115,
    2173.081472,
    2174.51688,
    2175.951341,
    2177.384854,
    2178.81742,
    2180.24904,
    2181.679715,
    2183.109445,
    2184.53823,
    2185.966071,
    2187.39297,
    2188.818926,
    2190.24394,
    2191.668013,
    2193.091145,
    2194.513337,
    2195.93459,
    2197.354904,
    2198.77428,
    2200.192718,
    2201.610219,
    2203.026784,
    2204.442413,
    2205.857107,
    2207.270866,
    2208.683691,
    2210.095583,
    2211.506543,
    2212.91657,
    2214.325665,
    2215.73383,
    2217.141064,
    2218.547369,
    2219.952744,
    2221.357191,
    2222.76071,
    2224.163301,
    2225.564966,
    2226.965705,
    2228.365518,
    2229.764406,
    2231.16237,
    2232.55941,
    2233.955527,
    2235.350722,
    2236.744994,
    2238.138345,
    2239.530775,
    2240.922286,
    2242.312876,
    2243.702548,
    2245.091301,
    2246.479136,
    2247.866054,
    2249.252056,
    2250.637142,
    2252.021312,
    2253.404567,
    2254.786908,
    2256.168335,
    2257.548849,
    2258.928451,
    2260.30714,
    2261.684919,
    2263.061786,
    2264.437744,
    2265.812792,
    2267.186931,
    2268.560161,
    2269.932484,
    2271.303899,
    2272.674408,
    2274.04401,
    2275.412708,
    2276.7805,
    2278.147388,
    2279.513372,
    2280.878453,
    2282.242631,
    2283.605907,
    2284.968282,
    2286.329756,
    2287.69033,
    2289.050004,
    2290.408779,
    2291.766655,
    2293.123633,
    2294.479714,
    2295.834898,
    2297.189186,
    2298.542578,
    2299.895075,
    2301.246677,
    2302.597386,
    2303.9472,
    2305.296123,
    2306.644152,
    2307.991291,
    2309.337538,
    2310.682894,
    2312.02736,
    2313.370937,
    2314.713626,
    2316.055425,
    2317.396337,
    2318.736362,
    2320.075501,
    2321.413753,
    2322.75112,
    2324.087602,
    2325.423199,
    2326.757913,
    2328.091744,
    2329.424692,
    2330.756757,
    2332.087942,
    2333.418245,
    2334.747668,
    2336.076211,
    2337.403874,
    2338.730659,
    2340.056566,
    2341.381595,
    2342.705747,
    2344.029023,
    2345.351423,
    2346.672947,
    2347.993596,
    2349.313371,
    2350.632273,
    2351.950301,
    2353.267456,
    2354.58374,
    2355.899152,
    2357.213693,
    2358.527363,
    2359.840164,
    2361.152095,
    2362.463158,
    2363.773352,
    2365.082679,
    2366.391138,
    2367.698731,
    2369.005458,
    2370.31132,
    2371.616316,
    2372.920448,
    2374.223717,
    2375.526122,
    2376.827664,
    2378.128344,
    2379.428163,
    2380.72712,
    2382.025217,
    2383.322453,
    2384.61883,
    2385.914349,
    2387.209008,
    2388.50281,
    2389.795755,
    2391.087843,
    2392.379075,
    2393.669451,
    2394.958971,
    2396.247637,
    2397.535449,
    2398.822408,
    2400.108513,
    2401.393766,
    2402.678167,
    2403.961717,
    2405.244416,
    2406.526264,
    2407.807263,
    2409.087412,
    2410.366713,
    2411.645165,
    2412.92277,
    2414.199527,
    2415.475438,
    2416.750503,
    2418.024723,
    2419.298097,
    2420.570627,
    2421.842313,
    2423.113155,
    2424.383155,
    2425.652312,
    2426.920627,
    2428.188101,
    2429.454735,
    2430.720528,
    2431.985481,
    2433.249595,
    2434.51287,
    2435.775307,
    2437.036907,
    2438.297669,
    2439.557595,
    2440.816685,
    2442.074939,
    2443.332358,
    2444.588943,
    2445.844694,
    2447.099611,
    2448.353695,
    2449.606947,
    2450.859367,
    2452.110956,
    2453.361714,
    2454.611641,
    2455.860739,
    2457.109007,
    2458.356446,
    2459.603058,
    2460.848841,
    2462.093797,
    2463.337927,
    2464.58123,
    2465.823708,
    2467.06536,
    2468.306188,
    2469.546191,
    2470.785371,
    2472.023728,
    2473.261262,
    2474.497974,
    2475.733864,
    2476.968934,
    2478.203183,
    2479.436611,
    2480.66922,
    2481.901011,
    2483.131982,
    2484.362136,
    2485.591472,
    2486.81999,
    2488.047693,
    2489.274579,
    2490.50065,
    2491.725906,
    2492.950348,
    2494.173975,
    2495.396789,
    2496.61879,
    2497.839979,
    2499.060355,
    2500.27992,
    2501.498675,
    2502.716618,
    2503.933752,
    2505.150076,
    2506.365592,
    2507.580298,
    2508.794197,
    2510.007289,
    2511.219573,
    2512.431051,
    2513.641723,
    2514.85159,
    2516.060652,
    2517.268909,
    2518.476362,
    2519.683012,
    2520.888858,
    2522.093902,
    2523.298145,
    2524.501585,
    2525.704225,
    2526.906064,
    2528.107104,
    2529.307343,
    2530.506784,
    2531.705426,
    2532.90327,
    2534.100317,
    2535.296566,
    2536.492019,
    2537.686676,
    2538.880537,
    2540.073603,
    2541.265875,
    2542.457352,
    2543.648036,
    2544.837927,
    2546.027025,
    2547.21533,
    2548.402845,
    2549.589567,
    2550.7755,
    2551.960642,
    2553.144994,
    2554.328557,
    2555.511331,
    2556.693317,
    2557.874515,
    2559.054926,
    2560.23455,
    2561.413387,
    2562.591439,
    2563.768705,
    2564.945187,
    2566.120884,
    2567.295797,
    2568.469926,
    2569.643273,
    2570.815837,
    2571.987619,
    2573.158619,
    2574.328839,
    2575.498278,
    2576.666936,
    2577.834815,
    2579.001915,
    2580.168236,
    2581.333779,
    2582.498545,
    2583.662533,
    2584.825744,
    2585.988179,
    2587.149838,
    2588.310721,
    2589.47083,
    2590.630165,
    2591.788725,
    2592.946512,
    2594.103526,
    2595.259767,
    2596.415237,
    2597.569934,
    2598.723861,
    2599.877017,
    2601.029403,
    2602.181019,
    2603.331866,
    2604.481944,
    2605.631254,
    2606.779796,
    2607.92757,
    2609.074578,
    2610.220819,
    2611.366295,
    2612.511004,
    2613.654949,
    2614.798129,
    2615.940545,
    2617.082198,
    2618.223087,
    2619.363214,
    2620.502578,
    2621.64118,
    2622.779022,
    2623.916102,
    2625.052422,
    2626.187982,
    2627.322782,
    2628.456824,
    2629.590107,
    2630.722631,
    2631.854399,
    2632.985409,
    2634.115662,
    2635.245159,
    2636.3739,
    2637.501886,
    2638.629117,
    2639.755593,
    2640.881316,
    2642.006285,
    2643.130501,
    2644.253964,
    2645.376676,
    2646.498635,
    2647.619843,
    2648.740301,
    2649.860008,
    2650.978965,
    2652.097173,
    2653.214632,
    2654.331343,
    2655.447305,
    2656.56252,
    2657.676987,
    2658.790708,
    2659.903683,
    2661.015911,
    2662.127395,
    2663.238133,
    2664.348127,
    2665.457377,
    2666.565884,
    2667.673647,
    2668.780667,
    2669.886946,
    2670.992483,
    2672.097278,
    2673.201332,
    2674.304646,
    2675.40722,
    2676.509055,
    2677.61015,
    2678.710507,
    2679.810125,
    2680.909006,
    2682.007149,
    2683.104556,
    2684.201226,
    2685.29716,
    2686.392359,
    2687.486822,
    2688.580551,
    2689.673545,
    2690.765806,
    2691.857334,
    2692.948128,
    2694.03819,
    2695.12752,
    2696.216119,
    2697.303986,
    2698.391123,
    2699.477529,
    2700.563206,
    2701.648153,
    2702.732371,
    2703.81586,
    2704.898622,
    2705.980656,
    2707.061963,
    2708.142543,
    2709.222396,
    2710.301524,
    2711.379926,
    2712.457603,
    2713.534556,
    2714.610784,
    2715.686289,
    2716.76107,
    2717.835129,
    2718.908465,
    2719.981079,
    2721.052972,
    2722.124143,
    2723.194594,
    2724.264324,
    2725.333335,
    2726.401626,
    2727.469198,
    2728.536051,
    2729.602187,
    2730.667605,
    2731.732305,
    2732.796289,
    2733.859556,
    2734.922107,
    2735.983943,
    2737.045063,
    2738.105469,
    2739.16516,
    2740.224138,
    2741.282402,
    2742.339953,
    2743.396792,
    2744.452918,
    2745.508333,
    2746.563036,
    2747.617029,
    2748.670311,
    2749.722883,
    2750.774745,
    2751.825899,
    2752.876343,
    2753.926079,
    2754.975107,
    2756.023428,
    2757.071041,
    2758.117948,
    2759.164149,
    2760.209643,
    2761.254433,
    2762.298517,
    2763.341897,
    2764.384572,
    2765.426544,
    2766.467813,
    2767.508378,
    2768.548241,
    2769.587402,
    2770.625862,
    2771.66362,
    2772.700677,
    2773.737034,
    2774.772691,
    2775.807648,
    2776.841907,
    2777.875466,
    2778.908327,
    2779.94049,
    2780.971956,
    2782.002725,
    2783.032797,
    2784.062172,
    2785.090852,
    2786.118836,
    2787.146125,
    2788.17272,
    2789.198621,
    2790.223827,
    2791.24834,
    2792.272161,
    2793.295288,
    2794.317724,
    2795.339467,
    2796.36052,
    2797.380881,
    2798.400552,
    2799.419533,
    2800.437824,
    2801.455426,
    2802.472339,
    2803.488563,
    2804.504099,
    2805.518948,
    2806.533109,
    2807.546584,
    2808.559372,
    2809.571474,
    2810.58289,
    2811.593621,
    2812.603667,
    2813.613029,
    2814.621706,
    2815.6297,
    2816.637011,
    2817.643639,
    2818.649584,
    2819.654848,
    2820.65943,
    2821.66333,
    2822.66655,
    2823.669089,
    2824.670948,
    2825.672128,
    2826.672628,
    2827.67245,
    2828.671593,
    2829.670058,
    2830.667846,
    2831.664956,
    2832.661389,
    2833.657146,
    2834.652227,
    2835.646632,
    2836.640362,
    2837.633417,
    2838.625798,
    2839.617505,
    2840.608537,
    2841.598897,
    2842.588584,
    2843.577598,
    2844.56594,
    2845.553611,
    2846.54061,
    2847.526938,
    2848.512596,
    2849.497583,
    2850.481901,
    2851.46555,
    2852.448529,
    2853.43084,
    2854.412483,
    2855.393458,
    2856.373766,
    2857.353407,
    2858.332381,
    2859.310689,
    2860.288331,
    2861.265307,
    2862.241619,
    2863.217266,
    2864.192248,
    2865.166567,
    2866.140222,
    2867.113215,
    2868.085544,
    2869.057211,
    2870.028216,
    2870.99856,
    2871.968242,
    2872.937264,
    2873.905625,
    2874.873326,
    2875.840368,
    2876.80675,
    2877.772474,
    2878.737539,
    2879.701945,
    2880.665695,
    2881.628786,
    2882.591221,
    2883.553,
    2884.514122,
    2885.474588,
    2886.434399,
    2887.393555,
    2888.352056,
    2889.309903,
    2890.267096,
    2891.223636,
    2892.179522,
    2893.134756,
    2894.089337,
    2895.043266,
    2895.996544,
    2896.949171,
    2897.901146,
    2898.852471,
    2899.803146,
    2900.753172,
    2901.702548,
    2902.651275,
    2903.599353,
    2904.546783,
    2905.493566,
    2906.439701,
    2907.385188,
    2908.330029,
    2909.274224,
    2910.217773,
    2911.160676,
    2912.102934,
    2913.044547,
    2913.985516,
    2914.925841,
    2915.865522,
    2916.804559,
    2917.742954,
    2918.680706,
    2919.617815,
    2920.554283,
    2921.49011,
    2922.425295,
    2923.35984,
    2924.293744,
    2925.227008,
    2926.159633,
    2927.091618,
    2928.022964,
    2928.953672,
    2929.883742,
    2930.813174,
    2931.741969,
    2932.670126,
    2933.597647,
    2934.524532,
    2935.45078,
    2936.376393,
    2937.301371,
    2938.225714,
    2939.149423,
    2940.072497,
    2940.994938,
    2941.916745,
    2942.83792,
    2943.758461,
    2944.678371,
    2945.597648,
    2946.516294,
    2947.434309,
    2948.351693,
    2949.268446,
    2950.18457,
    2951.100063,
    2952.014928,
    2952.929163,
    2953.84277,
    2954.755748,
    2955.668099,
    2956.579822,
    2957.490917,
    2958.401386,
    2959.311229,
    2960.220445,
    2961.129036,
    2962.037001,
    2962.944341,
    2963.851057,
    2964.757148,
    2965.662615,
    2966.567459,
    2967.471679,
    2968.375277,
    2969.278252,
    2970.180604,
    2971.082336,
    2971.983445,
    2972.883934,
    2973.783802,
    2974.683049,
    2975.581676,
    2976.479684,
    2977.377073,
    2978.273842,
    2979.169993,
    2980.065526,
    2980.960441,
    2981.854738,
    2982.748418,
    2983.641481,
    2984.533928,
    2985.425759,
    2986.316974,
    2987.207573,
    2988.097558,
    2988.986927,
    2989.875683,
    2990.763824,
    2991.651352,
    2992.538266,
    2993.424568,
    2994.310257,
    2995.195334,
    2996.079798,
    2996.963652,
    2997.846894,
    2998.729525,
    2999.611546,
    3000.492956,
    3001.373757,
    3002.253949,
    3003.133531,
    3004.012504,
    3004.89087,
    3005.768627,
    3006.645776,
    3007.522318,
    3008.398253,
    3009.273582,
    3010.148304,
    3011.02242,
    3011.89593,
    3012.768835,
    3013.641136,
    3014.512831,
    3015.383923,
    3016.25441,
    3017.124294,
    3017.993575,
    3018.862253,
    3019.730329,
    3020.597802,
    3021.464673,
    3022.330943,
    3023.196612,
    3024.06168,
    3024.926148,
    3025.790015,
    3026.653283,
    3027.515951,
    3028.37802,
    3029.23949,
    3030.100362,
    3030.960636,
    3031.820312,
    3032.679391,
    3033.537873,
    3034.395758,
    3035.253047,
    3036.109739,
    3036.965836,
    3037.821338,
    3038.676245,
    3039.530557,
    3040.384274,
    3041.237398,
    3042.089928,
    3042.941865,
    3043.793208,
    3044.643959,
    3045.494118,
    3046.343685,
    3047.19266,
    3048.041044,
    3048.888837,
    3049.736039,
    3050.582651,
    3051.428673,
    3052.274105,
    3053.118948,
    3053.963202,
    3054.806868,
    3055.649945,
    3056.492435,
    3057.334336,
    3058.175651,
    3059.016378,
    3059.856519,
    3060.696074,
    3061.535042,
    3062.373425,
    3063.211223,
    3064.048436,
    3064.885064,
    3065.721108,
    3066.556568,
    3067.391444,
    3068.225737,
    3069.059447,
    3069.892575,
    3070.72512,
    3071.557083,
    3072.388464,
    3073.219264,
    3074.049484,
    3074.879122,
    3075.70818,
    3076.536658,
    3077.364557,
    3078.191876,
    3079.018616,
    3079.844778,
    3080.670361,
    3081.495366,
    3082.319793,
    3083.143643,
    3083.966916,
    3084.789612,
    3085.611732,
    3086.433276,
    3087.254244,
    3088.074636,
    3088.894454,
    3089.713697,
    3090.532365,
    3091.350459,
    3092.167979,
    3092.984926,
    3093.8013,
    3094.617101,
    3095.432329,
    3096.246985,
    3097.061069,
    3097.874582,
    3098.687524,
    3099.499894,
    3100.311694,
    3101.122924,
    3101.933584,
    3102.743675,
    3103.553196,
    3104.362148,
    3105.170531,
    3105.978346,
    3106.785593,
    3107.592273,
    3108.398385,
    3109.20393,
    3110.008908,
    3110.81332,
    3111.617166,
    3112.420446,
    3113.22316,
    3114.02531,
    3114.826894,
    3115.627915,
    3116.428371,
    3117.228263,
    3118.027591,
    3118.826357,
    3119.624559,
    3120.422199,
    3121.219277,
    3122.015792,
    3122.811747,
    3123.607139,
    3124.401971,
    3125.196242,
    3125.989953,
    3126.783103,
    3127.575694,
    3128.367725,
    3129.159198,
    3129.950111,
    3130.740466,
    3131.530263,
    3132.319502,
    3133.108183,
    3133.896308,
    3134.683875,
    3135.470886,
    3136.25734,
    3137.043238,
    3137.828581,
    3138.613368,
    3139.397601,
    3140.181278,
    3140.964401,
    3141.74697,
    3142.528986,
    3143.310447,
    3144.091356,
    3144.871711,
    3145.651515,
    3146.430765,
    3147.209464,
    3147.987612,
    3148.765208,
    3149.542253,
    3150.318747,
    3151.094691,
    3151.870085,
    3152.644929,
    3153.419223,
    3154.192968,
    3154.966165,
    3155.738813,
    3156.510913,
    3157.282464,
    3158.053469,
    3158.823925,
    3159.593835,
    3160.363198,
    3161.132015,
    3161.900286,
    3162.66801,
    3163.43519,
    3164.201824,
    3164.967913,
    3165.733458,
    3166.498458,
    3167.262915,
    3168.026828,
    3168.790197,
    3169.553024,
    3170.315307,
    3171.077049,
    3171.838248,
    3172.598905,
    3173.359021,
    3174.118595,
    3174.877629,
    3175.636122,
    3176.394075,
    3177.151487,
    3177.90836,
    3178.664694,
    3179.420488,
    3180.175744,
    3180.930461,
    3181.68464,
    3182.438281,
    3183.191384,
    3183.94395,
    3184.695979,
    3185.447471,
    3186.198427,
    3186.948847,
    3187.698731,
    3188.448079,
    3189.196893,
    3189.945171,
    3190.692915,
    3191.440124,
    3192.186799,
    3192.932941,
    3193.678549,
    3194.423624,
    3195.168166,
    3195.912176,
    3196.655654,
    3197.398599,
    3198.141013,
    3198.882896,
    3199.624247,
    3200.365068,
    3201.105358,
    3201.845118,
    3202.584348,
    3203.323049,
    3204.06122,
    3204.798863,
    3205.535977,
    3206.272562,
    3207.008619,
    3207.744148,
    3208.47915,
    3209.213625,
    3209.947573,
    3210.680994,
    3211.413889,
    3212.146257,
    3212.8781,
    3213.609418,
    3214.34021,
    3215.070478,
    3215.800221,
    3216.529439,
    3217.258134,
    3217.986305,
    3218.713952,
    3219.441076,
    3220.167678,
    3220.893757,
    3221.619313,
    3222.344348,
    3223.068861,
    3223.792853,
    3224.516323,
    3225.239273,
    3225.961702,
    3226.683611,
    3227.405001,
    3228.12587,
    3228.84622,
    3229.566051,
    3230.285363,
    3231.004157,
    3231.722432,
    3232.44019,
    3233.15743,
    3233.874153,
    3234.590358,
};
}

class MainWindow : public QMainWindow {
    Q_OBJECT
    friend struct HandshakeTest;
    friend struct SimulatedRunner;   // macos-native/sim_runner: clicks these controls without showing the window

public:
    MainWindow(QWidget *parent = nullptr)
        : QMainWindow(parent), laserOn(false), paused(false),
        isCollecting(false)
    {
        auto *central = new QWidget; central->setObjectName("appRoot");
        auto *rootLayout = new QVBoxLayout; rootLayout->setContentsMargins(0, 0, 0, 0); rootLayout->setSpacing(0);

        auto *powerText = new QLabel("Power"); powerText->setObjectName("fieldLabel");
        powerCombo = new QComboBox;
        powerCombo->addItems({"Low", "Medium", "High"});
        powerCombo->setCurrentIndex(2);
        selectedPower = PowerLevel::High;

        auto *laserButton       = new QPushButton("Laser ON");
        auto *ramanStartButton  = new QPushButton("Start Z scan then 2D scan");
        auto *lineStartButton = new QPushButton("1D Scan");
        lineAxisCombo = new QComboBox;
        lineAxisCombo->addItem("Y axis", "1d-y");
        lineAxisCombo->addItem("X axis", "1d-x");
        lineStartButton->setToolTip("Home ONLY the selected axis; acquire 0, 2, ... 24 mm (13 points). Other axis and Z stay fixed. Check clearance first.");
        auto *ramanStopButton   = new QPushButton("Stop");
        auto *pauseButton       = new QPushButton("Pause");
        auto *resumeButton      = new QPushButton("Resume");

        monitorButton = new QPushButton("Monitor: OFF");
        monitorButton->setCheckable(true);
        oneShotButton = new QPushButton("Draw Once");

        auto *darkButton = new QPushButton("Capture Dark");
        auto *analyzeButton = new QPushButton("Analyze Latest (CNN)");

        // Which sample, measured by whom and where (data_layer/PROTOCOL.md section 2.1): saved with every spectrum.
        sampleIdEdit = new QLineEdit; operatorEdit = new QLineEdit; locationEdit = new QLineEdit; notesEdit = new QLineEdit;
        // The Studio and raman_sim_runner take at most 200 characters per field. A longer text would
        // only be refused later, when the data layer registers the spectrum. The validator comes before
        // any text, the test values and the remembered ones included.
        for (QLineEdit* field : {sampleIdEdit, operatorEdit, locationEdit, notesEdit}) {
            field->setMaxLength(200);
            field->setValidator(new WholeCharacterValidator(field));
        }
        for (QLineEdit* required : {sampleIdEdit, operatorEdit, locationEdit}) required->setPlaceholderText("required");
        notesEdit->setPlaceholderText("optional");
        auto *captureButton = new QPushButton("Capture Spectrum");
        captureButton->setToolTip("Save ONE spectrum at the current position. Laser ON first; no motor motion.");
#ifdef HANDSHAKE_TESTING
        // The test build starts with the required fields filled in, so that a scan test can start a scan.
        sampleIdEdit->setText("TEST-SAMPLE"); operatorEdit->setText("handshake tests"); locationEdit->setText("test bench");
#endif
        if (remembersOperatorFields()) {
            operatorEdit->setText(QSettings().value("capture/operator").toString());
            locationEdit->setText(QSettings().value("capture/location").toString());
            connect(operatorEdit, &QLineEdit::textChanged, this, [](const QString& text) { QSettings().setValue("capture/operator", text.trimmed()); });
            connect(locationEdit, &QLineEdit::textChanged, this, [](const QString& text) { QSettings().setValue("capture/location", text.trimmed()); });
        }

        // Drawn by the ordinary painter, not through OpenGL: the OpenGL path of Qt Charts draws a line of
        // one device pixel on macOS, a hairline on a high-resolution screen, and a spectrum of 2048 points
        // needs no acceleration.
        rtSeries = new QLineSeries;
        rtChart = new QChart(); rtChart->addSeries(rtSeries); rtChart->legend()->hide();
        rtChart->setTitle("Raman Spectrum (real-time)");
        rtAxX = new QValueAxis; rtAxX->setTitleText("Raman shift (cm\u207B\u00B9)"); rtAxX->setRange(0, 3300);
        rtAxY = new QValueAxis; rtAxY->setTitleText("Intensity");
        rtChart->addAxis(rtAxX, Qt::AlignBottom); rtChart->addAxis(rtAxY, Qt::AlignLeft);
        rtSeries->attachAxis(rtAxX); rtSeries->attachAxis(rtAxY);
        chartView = new QChartView(rtChart); chartView->setRenderHint(QPainter::Antialiasing);
        chartView->setMinimumSize(360, 180); chartView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        chartView->setFrameShape(QFrame::NoFrame); rtChart->setMargins(QMargins(4, 2, 10, 2));
        rtAxX->setLabelFormat("%.0f"); rtAxY->setLabelFormat("%.0f"); useRoundTicks(rtChart, rtAxX, Qt::Horizontal); useRoundTicks(rtChart, rtAxY, Qt::Vertical);
        rtAxY->setRange(0, 1000);    // a scale to show before the first spectrum; every displayed spectrum sets its own
        chartView->setMouseTracking(true); chartView->viewport()->setMouseTracking(true);
        chartView->installEventFilter(this); chartView->viewport()->installEventFilter(this);

        laserOutput = new QTextEdit; laserOutput->setReadOnly(true); laserOutput->setObjectName("log");
        ramanOutput = new QTextEdit; ramanOutput->setReadOnly(true); ramanOutput->setObjectName("log");

        // ---- Arrangement of the window. Display only: the controls created above keep their texts and
        // their connections, which follow further down; what is created here shows state, or belongs to
        // the data layer.
        // Header: the states the operator must be able to read from across the bench.
        auto *header = new QFrame; header->setObjectName("header"); header->setFixedHeight(50);
        auto *headerRow = new QHBoxLayout(header); headerRow->setContentsMargins(16, 0, 14, 0); headerRow->setSpacing(8);
        auto *titleColumn = new QVBoxLayout; titleColumn->setSpacing(0); titleColumn->setContentsMargins(0, 0, 10, 0);
        auto *appTitle = new QLabel("Portable Raman Controller"); appTitle->setObjectName("appTitle");
        auto *appSubtitle = new QLabel(QString("DataFed edition %1").arg(kSoftwareVersion)); appSubtitle->setObjectName("appSubtitle");
        titleColumn->addStretch(); titleColumn->addWidget(appTitle); titleColumn->addWidget(appSubtitle); titleColumn->addStretch();
        display.simulation = new StatusPill(QString()); display.simulation->setShrinkable();
        display.backend = new StatusPill("BACKEND"); display.laser = new StatusPill("LASER");
        display.scan = new StatusPill("SCAN"); display.data = new StatusPill("DATA"); display.data->setShrinkable();
        headerRow->addLayout(titleColumn); headerRow->addWidget(display.simulation); headerRow->addStretch();
        for (StatusPill* pill : {display.backend, display.laser, display.scan, display.data}) headerRow->addWidget(pill);
        display.hazard = new HazardBand;
        rootLayout->addWidget(header); rootLayout->addWidget(display.hazard);
        // The simulation variables are read by the helper programs when they start, so the badge never changes.
        const PillState simulation = simulationHeaderBadge(kHelpersHaveSimulators);
        showPill(display.simulation, simulation);

        // Left column: the controls in the order they are used, each group under its title.
        const auto row = [](std::initializer_list<QPair<QWidget*, int>> widgets) {
            auto *line = new QHBoxLayout; line->setSpacing(6);
            for (const auto& widget : widgets) line->addWidget(widget.first, widget.second);
            return line;
        };
        auto *sampleGroup = new TitledGroup("Sample");
        auto *sampleGrid = new QGridLayout; sampleGrid->setHorizontalSpacing(8); sampleGrid->setVerticalSpacing(5);
        const QList<QPair<QString, QLineEdit*>> sampleFields{{"Sample ID", sampleIdEdit}, {"Operator", operatorEdit}, {"Location", locationEdit}, {"Notes", notesEdit}};
        for (int line = 0; line < sampleFields.size(); ++line) {
            auto *name = new QLabel(sampleFields[line].first); name->setObjectName("fieldLabel");
            sampleGrid->addWidget(name, line, 0); sampleGrid->addWidget(sampleFields[line].second, line, 1);
        }
        sampleGroup->body()->addLayout(sampleGrid);
        display.laserGroup = new TitledGroup("Laser");
        laserButton->setObjectName("laserButton"); display.laserButton = laserButton;
        display.laserGroup->body()->addLayout(row({{powerText, 0}, {powerCombo, 1}})); display.laserGroup->body()->addWidget(laserButton);
        auto *scanGroup = new TitledGroup("Scan");
        // Which of these is the brightest ("primary") follows the state: refreshStatusDisplay.
        display.zScanButton = ramanStartButton; display.lineScanButton = lineStartButton;
        display.captureButton = captureButton; display.darkButton = darkButton;
        ramanStopButton->setProperty("role", "stop"); display.stopButton = ramanStopButton; display.pauseButton = pauseButton;
        scanGroup->body()->addWidget(ramanStartButton); scanGroup->body()->addLayout(row({{lineAxisCombo, 2}, {lineStartButton, 3}}));
        scanGroup->body()->addLayout(row({{pauseButton, 1}, {resumeButton, 1}, {ramanStopButton, 1}}));
        auto *captureGroup = new TitledGroup("Capture");
        // The dark the next scan is paired with stands in the group's title row: the left column has no
        // height to spare for a line of its own at the smallest supported window size.
        display.nextDark = new ElidedLabel;
        QLabel* captureTitle = captureGroup->findChild<QLabel*>("groupTitle");
        auto *captureTitleRow = new QHBoxLayout; captureTitleRow->setSpacing(8);
        captureGroup->body()->removeWidget(captureTitle);
        captureTitleRow->addWidget(captureTitle); captureTitleRow->addStretch(1); captureTitleRow->addWidget(display.nextDark);
        captureGroup->body()->insertLayout(0, captureTitleRow);
        captureGroup->body()->addLayout(row({{captureButton, 5}, {darkButton, 4}})); captureGroup->body()->addLayout(row({{monitorButton, 5}, {oneShotButton, 4}}));
        auto *analysisGroup = new TitledGroup("Analysis");
        analysisGroup->body()->addWidget(analyzeButton);
        auto *studioButton = new QPushButton("Open Simulation Studio"); studioButton->setProperty("role", "quiet");
        auto *leftColumn = new QWidget;
        auto *leftLayout = new QVBoxLayout(leftColumn); leftLayout->setContentsMargins(0, 0, 0, 0); leftLayout->setSpacing(7);
        for (QWidget* group : {static_cast<QWidget*>(sampleGroup), static_cast<QWidget*>(display.laserGroup), static_cast<QWidget*>(scanGroup),
                               static_cast<QWidget*>(captureGroup), static_cast<QWidget*>(analysisGroup)}) leftLayout->addWidget(group);
        leftLayout->addStretch(); leftLayout->addWidget(studioButton);
        // The Tab key walks the controls from top to bottom, as they stand in the column.
        const QList<QWidget*> tabOrder{sampleIdEdit, operatorEdit, locationEdit, notesEdit, powerCombo, laserButton, ramanStartButton,
                                       lineAxisCombo, lineStartButton, pauseButton, resumeButton, ramanStopButton, captureButton, darkButton,
                                       monitorButton, oneShotButton, analyzeButton, studioButton};
        for (int next = 1; next < tabOrder.size(); ++next) QWidget::setTabOrder(tabOrder[next - 1], tabOrder[next]);
        // On a screen lower than the smallest supported window the column scrolls instead of being cut off.
        auto *leftScroll = new QScrollArea; leftScroll->setWidget(leftColumn); leftScroll->setWidgetResizable(true);
        leftScroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff); leftScroll->setFixedWidth(284);
        leftScroll->viewport()->setAutoFillBackground(false); leftColumn->setAutoFillBackground(false);

        // Centre: what happened last, in one readable line, over the spectrum.
        auto *chartCard = new QFrame; chartCard->setObjectName("card");
        auto *chartLayout = new QVBoxLayout(chartCard); chartLayout->setContentsMargins(8, 8, 8, 4); chartLayout->setSpacing(2);
        display.lastEvent = new EventLine;
        chartLayout->addWidget(display.lastEvent); chartLayout->addWidget(chartView, 1);

        // Below the chart: the two logs, and the Data and Review tabs of the data layer.
        auto *activityPage = new QWidget;
        auto *activityRow = new QHBoxLayout(activityPage); activityRow->setContentsMargins(10, 8, 10, 10); activityRow->setSpacing(12);
        const QList<QPair<QString, QTextEdit*>> logs{{"LASER AND BACKEND", laserOutput}, {"SCAN, CAPTURE AND ANALYSIS", ramanOutput}};
        for (const auto& log : logs) {
            auto *column = new QVBoxLayout; column->setSpacing(4);
            auto *caption = new QLabel(log.first); caption->setObjectName("paneTitle");
            column->addWidget(caption); column->addWidget(log.second, 1); activityRow->addLayout(column, 1);
            // A log that showed its newest line keeps showing it when lines are added or its height changes
            // (another tab was open, the divider was moved); one the operator scrolled back in stays put.
            QScrollBar* bar = log.second->verticalScrollBar();
            connect(bar, &QScrollBar::rangeChanged, this, [bar, lastEnd = std::make_shared<int>(0)](int, int end) {
                if (bar->value() >= *lastEnd) bar->setValue(end);
                *lastEnd = end;
            });
        }
#ifdef Q_OS_WIN
        const QString dataLayerFallbackPython = QStringLiteral("python");
#else
        const QString dataLayerFallbackPython = ramanAnalysisPython();
#endif
        // Created before the central widget is handed to the window: children are deleted in the order
        // they were added, so the panels stop reacting before the widgets they show are gone.
        dataPanels = new DataPanels(ramanHome(), dataLayerFallbackPython, operatorEdit, this);
        dataPanels->changed = [this] { refreshDataDisplay(); };
        display.tabs = new QTabWidget;
        display.tabs->addTab(activityPage, "Activity"); display.tabs->addTab(dataPanels->dataPage(), "Data"); display.tabs->addTab(dataPanels->reviewPage(), "Review");
        display.split = new QSplitter(Qt::Vertical); display.split->setChildrenCollapsible(false); display.split->setHandleWidth(10);
        display.split->addWidget(chartCard); display.split->addWidget(display.tabs);
        connect(display.tabs, &QTabWidget::currentChanged, this, [this](int tab) {
            applyTabSplit();
            if (tab != 0) dataPanels->pageShown();
        });
        connect(display.split, &QSplitter::splitterMoved, this, [this] {
            const QList<int> sizes = display.split->sizes();
            if (sizes[0] + sizes[1] > 0) display.tabShare[display.tabs->currentIndex() == 0 ? 0 : 1] = double(sizes[1]) / (sizes[0] + sizes[1]);
        });
        applyTabSplit();
        auto *body = new QHBoxLayout; body->setContentsMargins(10, 4, 10, 10); body->setSpacing(10);
        body->addWidget(leftScroll); body->addWidget(display.split, 1);
        rootLayout->addLayout(body, 1);
        central->setLayout(rootLayout); setCentralWidget(central);
        setWindowTitle(simulation.text == "SIMULATION" ? "Portable Raman Controller (SIMULATION)" : "Portable Raman Controller");
        statusBar()->setSizeGripEnabled(false);
        // The folder name ends where the body ends, clear of the window's rounded corner.
        statusBar()->setContentsMargins(0, 0, 10, 0);
        auto *homeLabel = new ElidedLabel(Qt::ElideMiddle);
        homeLabel->setText("Data folder: " + QDir::toNativeSeparators(ramanHome()));
        statusBar()->addPermanentWidget(homeLabel);

        // What the display follows. These connections only read: the two logs for the "last event" line,
        // the required fields for their mark, the system appearance for the colours.
        for (QTextEdit* log : {laserOutput, ramanOutput})
            connect(log->document(), &QTextDocument::contentsChanged, this, [this, log]() { noteLogLines(log); });
        for (QLineEdit* required : {sampleIdEdit, operatorEdit, locationEdit}) {
            const auto mark = [required]() { setStyleProperty(required, "missing", required->text().trimmed().isEmpty()); };
            connect(required, &QLineEdit::textChanged, this, mark);
            mark();
        }
        applyTheme(UiTheme::forApplication());
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
        connect(QGuiApplication::styleHints(), &QStyleHints::colorSchemeChanged, this, [this]() { applyTheme(UiTheme::forApplication()); });
#endif
        display.timer = new QTimer(this); display.timer->setInterval(200);
        connect(display.timer, &QTimer::timeout, this, [this]() { refreshStatusDisplay(); });
        if (!dataPanels->installed()) {
            studioButton->setEnabled(false);
            studioButton->setToolTip("The data layer is not installed; the Simulation Studio is part of it.");
        }
        connect(studioButton, &QPushButton::clicked, this, [this, studioButton]() {
            studioButton->setEnabled(false);
            dataPanels->openStudio([this, studioButton](bool ok, const QString& text) {
                studioButton->setEnabled(true);
                studioButton->setToolTip(ok ? "The Simulation Studio runs at " + text : text);
                statusBar()->showMessage(ok ? "Simulation Studio opened: " + text : text);
            });
        });

        QString savePath = ramanHome() + "/laser_log.txt";
        laserTxtFile.setFileName(savePath);
        laserTxtFile.open(QIODevice::Append | QIODevice::Text);

        laserProcess = new QProcess(this);
#ifndef Q_OS_WIN
        {   // Mac-native safety stop: tell the helper which process to watch (macos-native/backend/SampleApl/Watchdog.cs).
            QProcessEnvironment helperEnvironment = QProcessEnvironment::systemEnvironment();
            helperEnvironment.insert("RAMAN_CONTROLLER_PID", QString::number(QCoreApplication::applicationPid()));
            laserProcess->setProcessEnvironment(helperEnvironment);
        }
#endif
#ifdef Q_OS_WIN
        const QString laserExe = ramanHome() + "/handshake_v2/backend/SampleApl.exe";
#else
        // Mac-native deploy: a launcher script without .exe (macos-native/PORT_SPEC.md section 1).
        const QString laserExe = ramanHome() + "/handshake_v2/backend/SampleApl";
#endif
        const QString runtimeDir = ramanHome() + "/scan_sessions/_backend_" +
                                   QUuid::createUuid().toString(QUuid::WithoutBraces);
        if (!QDir().mkpath(runtimeDir)) { appendLaserLog("[Error] Cannot create backend runtime directory."); backendCaptureFault = true; }
        laserProcess->setWorkingDirectory(runtimeDir);
        laserProcess->setProcessChannelMode(QProcess::MergedChannels);
        laserProcess->start(laserExe);
        if (!laserProcess->waitForStarted(3000)) appendLaserLog("[Error] Could not start backend: " + laserExe);
        else appendLaserLog("[Backend process started]");

        connect(laserProcess, &QProcess::readyReadStandardOutput, this, [this]() {
            QString text = laserProcess->readAllStandardOutput();
            laserReplyBuffer = (laserReplyBuffer + text).right(32768);
            // stdout arrives in arbitrary chunks; never split a 2048-pixel row in the ML log.
            backendLineBuffer += text;
            qsizetype newline = -1;
            while ((newline = backendLineBuffer.indexOf('\n')) >= 0) {
                const QString line = backendLineBuffer.left(newline).trimmed();
                backendLineBuffer.remove(0, newline + 1);
                if (line.startsWith("MONITOR_FRAME ")) {
                    const QByteArray payload = line.mid(14).toUtf8();
                    if (!pendingMonitorId.isEmpty() && payload.startsWith(("CAPTURE " + pendingMonitorId + " ").toUtf8()))
                        monitorReply = payload;
                    continue; // Preview pixels never go to the log or text widget.
                }
                readBackendReport(line);
                if (!line.isEmpty()) appendLaserLog("[Backend] " + line);
            }
        });
        connect(laserProcess, &QProcess::readyReadStandardError, this, [this]() {
            QString text = laserProcess->readAllStandardError();
            if (!text.trimmed().isEmpty()) appendLaserLog("[Backend ERROR] " + text.trimmed());
        });

        ramanProcess = new QProcess(this);
#ifndef Q_OS_WIN
        {   // Mac-native safety stop: the motor program watches the controller too (macos-native/motor/scan_handshake.py).
            QProcessEnvironment helperEnvironment = QProcessEnvironment::systemEnvironment();
            helperEnvironment.insert("RAMAN_CONTROLLER_PID", QString::number(QCoreApplication::applicationPid()));
            ramanProcess->setProcessEnvironment(helperEnvironment);
        }
#endif
#ifdef HANDSHAKE_TESTING
        const QString ramanDir = ramanHome() + "/handshake_v2/motor";
#else
        const QString ramanDir = ramanHome() + "/handshake_v2/motor";
#endif
#ifdef Q_OS_WIN
        QString ramanExe = ramanDir + "\\RamanAutofocus.exe";
#else
        QString ramanExe = ramanDir + "/RamanAutofocus";
#endif
        ramanProcess->setWorkingDirectory(ramanDir);

        const auto startScan = [this, ramanExe](const QString& mode) {
            if (!requiredFieldsFilled("[Scan]")) return;
            if (monitorActive) { ramanOutput->append("[Scan] Stop Focus Monitor before motor scanning."); return; }
            if (laserCommandBusy || isCollecting) { ramanOutput->append("[Scan] Please wait for the current operation."); return; }
            if (laserProcess->state() != QProcess::Running) { ramanOutput->append("[Scan] Laser backend is not running."); return; }
            if (!laserOn) { ramanOutput->append("[Scan] Turn on the laser and confirm its status before starting the scan."); return; }
            if (ramanProcess->state() != QProcess::NotRunning) { ramanOutput->append("[Already running]"); return; }
            if (backendCaptureFault) { ramanOutput->append("[Scan] Capture fault: confirm Laser OFF, close and restart the app before a new run."); return; }
            currentScanMode = mode;
            sessionId = QUuid::createUuid().toString(QUuid::WithoutBraces);
            const QString root = ramanHome() + "/scan_sessions";
            const QString label = mode == "1d-x" ? "1d_x_scan" : mode == "1d-y" ? "1d_y_scan" : "2d_scan";
            const QString base = label + "_" + QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss_zzz");
            if (!QDir().mkpath(root)) { ramanOutput->append("[Scan] Cannot create data directory."); return; }
            QString folder = base;
            for (int suffix = 1; QDir(root).exists(folder); ++suffix) folder = base + "_" + QString::number(suffix);
            sessionDir = root + "/" + folder;
            if (!QDir(root).mkdir(folder)) { ramanOutput->append("[Scan] Cannot create unique data directory."); return; }
            // The fields and the laser level are taken once, here; every point of this scan carries this copy.
            scanCapture = captureMetadata();
            if (!publishSessionFile(sessionDir, sessionId, mode, scanCapture)) {
                QDir(root).rmdir(folder);
                ramanOutput->append("[Scan] Cannot create session.json."); return;
            }
            paused = false; pausedStepNotified = false; scanCancelled = false; scanActive = true;
            lastCompletedPoint = 0;
            combinedScanTxt.clear();
            ramanOutput->append("[Handshake v2] Data: " + sessionDir);
            ramanOutput->append("[Motor executable] " + ramanExe);
            QStringList args{sessionDir, sessionId};
            if (mode != "2d") {
                args << mode;
                ramanOutput->append("[1D Scan] " + mode + ": home selected axis; 0..24 mm, step 2 mm, 13 points. Other axis and Z unchanged.");
            }
            lineAxisCombo->setEnabled(false);
            setOperatorFieldsLocked(true);
            ramanProcess->start(ramanExe, args);
            if (!ramanProcess->waitForStarted(3000)) {
                stopRamanDataCollection();
                ramanOutput->append("[Error] Could not start: " + ramanExe);
            }
        };
        connect(ramanStartButton, &QPushButton::clicked, this, [startScan]() { startScan("2d"); });
        connect(lineStartButton, &QPushButton::clicked, this, [this, startScan]() { startScan(lineAxisCombo->currentData().toString()); });
        connect(ramanStopButton, &QPushButton::clicked, this, [this]() {
            stopFocusMonitor();
            stopMotorScan();
            ramanOutput->append("[Stop] Scan stopped. This does not switch the laser off.");
        });

        connect(darkButton, &QPushButton::clicked, this, [this]() { captureDarkMeasurement(); });
        connect(captureButton, &QPushButton::clicked, this, [this]() { captureSingleSpectrum(); });

        analysisProcess = new QProcess(this);
        analysisProcess->setProcessChannelMode(QProcess::MergedChannels);
        connect(analyzeButton, &QPushButton::clicked, this, [this]() {
            if (analysisProcess->state() != QProcess::NotRunning) { ramanOutput->append("[Analysis] Already running..."); return; }
            if (!QFile::exists(kPythonScriptPath)) { ramanOutput->append("[Analysis Error] Script not found: " + kPythonScriptPath); return; }
            const QString targetFile = findLatestAnalysisTargetFile();
            if (targetFile.isEmpty()) { ramanOutput->append("[Analysis Error] No file found."); return; }
            ramanOutput->append("<b>[Analysis] Starting...</b>");
            ramanOutput->append("[Analysis] Target: " + targetFile);
#ifdef Q_OS_WIN
            const QString pythonInterpreter = QStringLiteral("python");
#else
            const QString pythonInterpreter = ramanAnalysisPython();   // RAMAN_PYTHON, raman_python.txt, else python3
#endif
            analysisProcess->start(pythonInterpreter, QStringList() << kPythonScriptPath << targetFile);
        });
        connect(analysisProcess, &QProcess::readyReadStandardOutput, this, [this]() {
            QString output = analysisProcess->readAllStandardOutput();
            if (!output.isEmpty()) { ramanOutput->append(output.trimmed()); ramanOutput->moveCursor(QTextCursor::End); }
        });
        connect(analysisProcess, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
                this, [this](int code, QProcess::ExitStatus) { ramanOutput->append(QString("<b>[Analysis] Finished</b> (Code: %1)").arg(code)); });

        connect(pauseButton, &QPushButton::clicked, this, [this]() {
            if (!paused) {
                const QString snap = snapshotCurrentLogToNewFile();
                ramanOutput->append(snap.isEmpty() ? "[Paused] Failed to save snapshot." : "[Paused] Snapshot: " + snap);
                paused = true; pausedStepNotified = false;
                ramanOutput->append("[Paused] Incoming STEP will be held.");
            } else {
                const QString snap = snapshotCurrentLogToNewFile();
                ramanOutput->append(snap.isEmpty() ? "[Paused] Failed." : "[Paused] Additional snapshot: " + snap);
                ramanOutput->append("[Paused] Already paused.");
            }
        });
        connect(resumeButton, &QPushButton::clicked, this, [this]() {
            if (laserCommandBusy || isCollecting) { ramanOutput->append("[Resume] Wait for the current operation."); return; }
            if (!scanActive || scanCancelled || !laserOn || ramanProcess->state() != QProcess::Running) {
                ramanOutput->append("[Resume] No paused active scan. A failed/aborted scan cannot resume."); return;
            }
            paused = false; pausedStepNotified = false;
            ramanOutput->append("[Resume] Continuing the same pending point; existing data preserved.");
        });

        connect(ramanProcess, &QProcess::readyReadStandardOutput, this, [this]() {
            QString text = ramanProcess->readAllStandardOutput();
            if (!text.trimmed().isEmpty()) ramanOutput->append("[Raman] " + text.trimmed());
        });
        connect(ramanProcess, &QProcess::readyReadStandardError, this, [this]() {
            QString text = ramanProcess->readAllStandardError();
            if (!text.trimmed().isEmpty()) ramanOutput->append("[Raman ERROR] " + text.trimmed());
        });
        connect(ramanProcess, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
                this, [this](int code, QProcess::ExitStatus status) {
                    ramanOutput->append(QString("[Raman exited] code=%1, status=%2").arg(code).arg(status==QProcess::NormalExit?"Normal":"Crash"));
                    stopRamanDataCollection();
                });

        auto *stepTimer = new QTimer(this);
        stepTimer->setInterval(50);
        connect(stepTimer, &QTimer::timeout, this, &MainWindow::handleScanPoint);
        stepTimer->start();

        connect(powerCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [this](int idx){ selectedPower = static_cast<PowerLevel>(idx); });

        connect(laserButton, &QPushButton::clicked, this, [this, laserButton, ramanStartButton, darkButton]() {
            if (laserCommandBusy) return;
            if (isCollecting) { appendLaserLog("[Laser] Acquisition in progress; wait for completion before changing laser power."); return; }
            if (laserProcess->state() != QProcess::Running) { appendLaserLog("[Laser] Backend is not running."); return; }
            QScopedValueRollback<bool> commandGuard(laserCommandBusy, true);
            laserButton->setEnabled(false);
            ramanStartButton->setEnabled(false);
            darkButton->setEnabled(false);
            powerCombo->setEnabled(false);
            const bool enable = !laserOn && !laserStateUncertain;
            if (!enable) stopFocusMonitor();
            // Preserve stop-on-laser-off behavior. Laser ON never starts the motor.
            if (!enable && ramanProcess->state() != QProcess::NotRunning) {
                stopMotorScan();
            }
            if (setLaserEnabledAndConfirm(enable)) {
                laserOn = enable;
                laserStateUncertain = false;
                display.laserReadBack = true;
                if (laserOn) powerInForce = sentPower;
                laserButton->setText(laserOn ? "Laser OFF" : "Laser ON");
                appendLaserLog(laserOn ? "[Laser] ON confirmed. Click Start Z scan then 2D scan to begin scanning."
                                      : "[Laser] OFF confirmed.");
            } else {
                // An unconfirmed command must not leave Start Scan enabled by a stale state.
                laserOn = false;
                laserButton->setText("Confirm Laser OFF");
                laserStateUncertain = true;
                appendLaserLog("[Laser] State unconfirmed; scanning blocked. Check backend output and confirm Laser OFF before retrying.");
            }
            laserButton->setEnabled(true);
            ramanStartButton->setEnabled(true);
            darkButton->setEnabled(true);
            powerCombo->setEnabled(true);
        });

        mappingLogPath = ramanHome() + "/laser_log.txt";
        rtTimer = new QTimer(this); rtTimer->setSingleShot(true);
        monitorButton->setToolTip("Live focus preview: Laser ON first. No motor motion; no spectra saved.");
        connect(monitorButton, &QPushButton::toggled, this, [this](bool on){
            if (!on) { stopFocusMonitor(); return; }
            if (!laserOn || laserStateUncertain || laserCommandBusy || isCollecting || scanActive ||
                backendCaptureFault || laserProcess->state() != QProcess::Running ||
                ramanProcess->state() != QProcess::NotRunning) {
                ramanOutput->append("[Focus Monitor] Requires Laser ON and an idle, healthy backend. Stop scan/dark capture first.");
                stopFocusMonitor(); return;
            }
            monitorActive = true;
            monitorButton->setText("Monitor: ON (Focus)");
            rtChart->setTitle("Focus preview - acquiring NEW spectrum (not saved)");
            rtSeries->clear();
            ramanOutput->append("[Focus Monitor] Live acquisition. No motor movement; spectra are not saved.");
            rtTimer->start(0);
        });
        connect(rtTimer, &QTimer::timeout, this, &MainWindow::captureFocusFrame);
        connect(oneShotButton, &QPushButton::clicked, this, [this](){
            if (!monitorActive && !isCollecting) refreshMappingFromLog();
        });
        setMinimumSize(1080, 660);
        resize(1440, 880);
        refreshStatusDisplay();
        refreshDataDisplay();
    }

    ~MainWindow() override {
        stopMotorScan();
        if (laserProcess && laserProcess->state() == QProcess::Running) {
            laserProcess->terminate();
#ifdef Q_OS_WIN
            const int backendStopWaitMs = 2000;
#else
            // The Mac-native backend switches the laser off when asked to terminate; its worst case is
            // GraceMs + EmergencyAttemptMs = 1700 ms (macos-native/backend/SampleApl/Watchdog.cs). Wait
            // longer than that before killing it, or the kill could cut the laser-off short.
            const int backendStopWaitMs = 3000;
#endif
            if (!laserProcess->waitForFinished(backendStopWaitMs)) { laserProcess->kill(); laserProcess->waitForFinished(2000); }
        }
        if (analysisProcess && analysisProcess->state() == QProcess::Running) analysisProcess->kill();
        stopRamanDataCollection();
        if (laserTxtFile.isOpen()) laserTxtFile.close();
    }

protected:
    // The status display and the data layer start when the window is first shown. A program that
    // drives this class without showing it (the tests, a headless run) gets no timer and no child
    // process from them.
    void showEvent(QShowEvent* event) override {
        QMainWindow::showEvent(event);
        if (display.timer->isActive()) return;
        fitToScreen();
        applyTabSplit();
        refreshStatusDisplay();
        display.timer->start();
        dataPanels->start();
    }
    void closeEvent(QCloseEvent* event) override {
        if (isCollecting || laserCommandBusy) {
            event->ignore();
            ramanOutput->append("[Close] Wait for the current capture/laser command to finish, then close again.");
            return;
        }
        QMainWindow::closeEvent(event);
    }
    bool eventFilter(QObject* obj, QEvent* event) override {
        if ((obj == chartView || obj == chartView->viewport()) && rtChart && rtSeries) {
            if (event->type() == QEvent::MouseMove) {
                auto *me = static_cast<QMouseEvent*>(event);
                QPointF value = rtChart->mapToValue(me->pos(), rtSeries);
                QWidget *w = qobject_cast<QWidget*>(obj);
                if (w) QToolTip::showText(w->mapToGlobal(me->pos()), QString("x: %1\ny: %2").arg(value.x(), 0, 'f', 2).arg(value.y(), 0, 'f', 2), w);
                statusBar()->showMessage(QString("x: %1, y: %2").arg(value.x(), 0, 'f', 2).arg(value.y(), 0, 'f', 2));
            } else if (event->type() == QEvent::Leave) { QToolTip::hideText(); statusBar()->clearMessage(); }
        }
        return QMainWindow::eventFilter(obj, event);
    }

private slots:
    void refreshMappingFromLog() {
        QVector<int> spectrum;
        if (!readLastImageDataHexAsInts_RT(mappingLogPath, spectrum)) return;
        if (spectrum.size() < 10) return;
        displaySpectrum(spectrum);
    }

    void displaySpectrum(const QVector<int>& spectrum) {
        QVector<QPointF> pts = spectrumToShiftCurve_RT(spectrum);
        if (pts.isEmpty()) return;
        rtSeries->replace(pts);
        int minY = INT_MAX, maxY = INT_MIN;
        for (const auto& p : pts) { int y = static_cast<int>(p.y()); if (y < minY) minY = y; if (y > maxY) maxY = y; }
        if (minY == INT_MAX) return;
        if (minY == maxY) { minY = std::max(0, minY - 10); maxY += 10; }
        rtAxY->setRange(minY, maxY);
    }

private:
    enum class PowerLevel { Low = 0, Medium = 1, High = 2 };
    PowerLevel selectedPower = PowerLevel::High;
    // The level sent with the latest Laser ON command, and the level in force: the sent one, taken
    // over only once the read-back has confirmed Laser ON. Moving the Power box afterwards changes
    // neither, so the recorded level is the one the laser was actually given.
    PowerLevel sentPower = PowerLevel::High;
    std::optional<PowerLevel> powerInForce;
    QLineEdit* sampleIdEdit = nullptr;
    QLineEdit* operatorEdit = nullptr;
    QLineEdit* locationEdit = nullptr;
    QLineEdit* notesEdit = nullptr;
    // Reported once by the capture backend (data_layer/PROTOCOL.md section 3); null until then.
    QJsonValue integrationTimeUs;
    QJsonValue instrumentInfo;
    QJsonObject scanCapture;     // "capture" block of the running scan, taken when it started
    QString singleCaptureDir;    // folder of the latest single capture
    // Display only: nothing in this block is read by the acquisition code.
    struct Display {
        StatusPill *simulation = nullptr, *backend = nullptr, *laser = nullptr, *scan = nullptr, *data = nullptr;
        HazardBand* hazard = nullptr;
        EventLine* lastEvent = nullptr;
        TitledGroup* laserGroup = nullptr;
        QPushButton *laserButton = nullptr, *stopButton = nullptr, *pauseButton = nullptr;
        QPushButton *zScanButton = nullptr, *lineScanButton = nullptr, *captureButton = nullptr, *darkButton = nullptr;
        ElidedLabel* nextDark = nullptr;      // the dark the next scan or single capture is paired with
        QJsonValue nextDarkFile;              // ... as darkForNextCapture() found it, when nothing was acquiring
        bool laserReadBack = false;           // a Laser ON or OFF has been confirmed by the read-back since the start
        QTabWidget* tabs = nullptr;
        QSplitter* split = nullptr;
        QTimer* timer = nullptr;
        double tabShare[2] = {0.38, 0.60};    // height share of the tab area: with the logs, with the Data or Review tab
        int laserLinesSeen = 0, scanLinesSeen = 0;
        QString sessionJudged;                // the scan session whose end lastScanEnd describes
        ControllerView::ScanEnd lastScanEnd = ControllerView::ScanEnd::None;
        QString singleCaptureSeen;
    } display;
    DataPanels* dataPanels = nullptr;
    QComboBox* powerCombo = nullptr;
    QComboBox* lineAxisCombo = nullptr;
    QString currentScanMode = "2d";
    QPushButton* monitorButton = nullptr;
    QPushButton* oneShotButton = nullptr;
    QTextEdit *laserOutput = nullptr;
    QTextEdit *ramanOutput = nullptr;
    bool laserOn;
    bool paused;
    bool pausedStepNotified = false;
    bool isCollecting;
    bool laserCommandBusy = false;
    bool laserStateUncertain = false;
    QString laserReplyBuffer;
    QString backendLineBuffer;
    QProcess *laserProcess = nullptr;
    QProcess *ramanProcess = nullptr;
    QProcess *analysisProcess = nullptr;
    bool backendCaptureFault = false;
    bool monitorActive = false;
    QString pendingMonitorId;
    QByteArray monitorReply;
    int monitorFrameCount = 0;
    bool scanActive = false;
    bool scanCancelled = true;
    QString sessionDir, sessionId;
    quint64 lastCompletedPoint = 0;
    QByteArray combinedScanTxt;
    QFile laserTxtFile;
    QChart* rtChart = nullptr;
    QLineSeries* rtSeries = nullptr;
    QValueAxis* rtAxX = nullptr;
    QValueAxis* rtAxY = nullptr;
    QChartView* chartView = nullptr;
    QTimer* rtTimer = nullptr;
    QString mappingLogPath;


    QString findLatestSnapshotLogFile() const {
        QDir dir(ramanHome());
        QFileInfoList files = dir.entryInfoList(QStringList() << "laser_log_*.txt", QDir::Files, QDir::Time);
        return files.isEmpty() ? QString() : files.first().absoluteFilePath();
    }
    QString findLatestAnalysisTargetFile() const {
        const QString snap = findLatestSnapshotLogFile();
        if (!snap.isEmpty() && QFile::exists(snap)) return snap;
        const QString live = laserTxtFile.fileName();
        if (!live.isEmpty() && QFile::exists(live)) return live;
        return QString();
    }
    QString powerCommandForLevel(PowerLevel lvl) const { switch(lvl){ case PowerLevel::Low: return "1"; case PowerLevel::Medium: return "2"; case PowerLevel::High: return "3"; } return "3"; }
    QString powerLevelString(PowerLevel lvl) const { switch(lvl){ case PowerLevel::Low: return "LOW"; case PowerLevel::Medium: return "MEDIUM"; case PowerLevel::High: return "HIGH"; } return "HIGH"; }

    // Operator and Location survive a restart only in the program started through main(), which
    // names the organisation. The test build, and any harness that builds the window itself, neither
    // loads nor stores them, so a test value can never come back as the real controller's operator.
    static bool remembersOperatorFields() {
#ifdef HANDSHAKE_TESTING
        return false;
#else
        return !QCoreApplication::organizationName().isEmpty();
#endif
    }

    // Sample ID, Operator and Location are required (data_layer/PROTOCOL.md section 2.1). Names the
    // empty ones in one line of the scan log; the caller then starts nothing.
    bool requiredFieldsFilled(const QString& tag) {
        QStringList missing;
        if (sampleIdEdit->text().trimmed().isEmpty()) missing << "Sample ID";
        if (operatorEdit->text().trimmed().isEmpty()) missing << "Operator";
        if (locationEdit->text().trimmed().isEmpty()) missing << "Location";
        if (missing.isEmpty()) return true;
        ramanOutput->append(tag + " Not started: fill in " + missing.join(", ") + " first.");
        return false;
    }

    // The fields describe the data being recorded, so they cannot be edited while it is recorded.
    void setOperatorFieldsLocked(bool locked) {
        for (QLineEdit* field : {sampleIdEdit, operatorEdit, locationEdit, notesEdit}) field->setReadOnly(locked);
    }

    // The two lines the capture backend prints once after initialising the device
    // (data_layer/PROTOCOL.md section 3). A backend that prints neither, or that reports the module
    // information as unavailable, leaves the value null.
    void readBackendReport(const QString& line) {
        if (line.startsWith("CAPTURE_SETTINGS ")) {
            const QRegularExpression exposure("(?:^|\\s)exposure_time_us=(\\d+)(?:\\s|$)");
            bool ok = false;
            const qint64 microseconds = exposure.match(line).captured(1).toLongLong(&ok);
            if (ok) integrationTimeUs = microseconds;
        } else if (line.startsWith("MODULE_INFO ")) {
            const QRegularExpression pair("(?:^|\\s)(\\w+)=\"([^\"]*)\"");
            QJsonObject info;
            for (auto pairs = pair.globalMatch(line); pairs.hasNext();) {
                const auto match = pairs.next();
                if (QStringList{"model", "serial", "unit", "firmware"}.contains(match.captured(1)))
                    info.insert(match.captured(1), match.captured(2));
            }
            if (!info.isEmpty()) instrumentInfo = info;
        }
    }

    // File name of the newest dark spectrum of one kind in the folder, simulated or real (lead
    // decision D1), or null: a dark of the other kind, or of unknown kind, is never chosen. The names
    // carry their capture time (dark_yyyyMMdd_HHmmss_zzz), which, unlike the modification time,
    // survives a copy: the darks copied from the original hand-off folder all share one modification
    // time. cnn_1.py orders dated files the same way. The modification time decides only when no name
    // of that kind is dated.
    static QJsonValue newestDarkFile(const QString& dir, bool simulated) {
        const QFileInfoList darks = QDir(dir).entryInfoList({"dark_*.txt"}, QDir::Files, QDir::Time);
        const QRegularExpression dated("^dark_\\d{8}_\\d{6}");
        QStringList datedNames, undatedNames;   // the undated ones stay newest first by modification time
        for (const QFileInfo& dark : darks) (dated.match(dark.fileName()).hasMatch() ? datedNames : undatedNames) << dark.fileName();
        std::sort(datedNames.begin(), datedNames.end(), [](const QString& a, const QString& b) { return a > b; });
        // Newest first, so that normally only the .json of the dark that is chosen is read.
        const DarkKind wanted = simulated ? DarkKind::Simulated : DarkKind::Real;
        for (const QString& name : datedNames + undatedNames)
            if (darkKind(QDir(dir).filePath(name)) == wanted) return name;
        return QJsonValue();
    }

    // Whether each helper program simulates, by its own rule applied to the environment it is started
    // with: "simulated" of session.json, of every capture block and of every dark's .json.
    QJsonObject simulatedFlags() const {
        return {{"backend", backendSimulates(startEnvironment(laserProcess))},
                {"motor", motorSimulates(startEnvironment(ramanProcess), ramanProcess->workingDirectory())}};
    }

    // The dark that a scan or single capture started now is paired with: the newest in
    // dark_measurements/ of the kind the capture backend gives (lead decision D1).
    QJsonValue darkForNextCapture() const {
        return newestDarkFile(ramanHome() + "/dark_measurements", backendSimulates(startEnvironment(laserProcess)));
    }

    // The "capture" block of data_layer/PROTOCOL.md section 2.3, taken once when a scan or a single
    // capture starts: editing a field or moving the Power box afterwards cannot change what is saved.
    QJsonObject captureMetadata() const {
        return QJsonObject{
            {"schema", "raman-capture/1"},
            {"sample_id", sampleIdEdit->text().trimmed()}, {"operator", operatorEdit->text().trimmed()},
            {"location", locationEdit->text().trimmed()}, {"notes", notesEdit->text().trimmed()},
            {"laser_power_level", powerInForce ? QJsonValue(powerLevelString(*powerInForce)) : QJsonValue()},
            {"integration_time_us", integrationTimeUs}, {"instrument", instrumentInfo},
            {"simulated", simulatedFlags()},
            {"dark_file", darkForNextCapture()},
            {"software", QJsonObject{{"name", kSoftwareName}, {"version", kSoftwareVersion}}}
        };
    }

    // session.json (data_layer/PROTOCOL.md section 2.2): written once, before any point of the session exists.
    static bool publishSessionFile(const QString& dir, const QString& id, const QString& mode, const QJsonObject& capture) {
        QJsonObject session = capture;
        session.insert("schema", "raman-session/1");
        session.insert("session_id", id);
        session.insert("folder", QFileInfo(dir).fileName());
        session.insert("scan_mode", mode);
        session.insert("started_utc", QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs));
        return AcquisitionProtocol::publish(dir + "/session.json", QJsonDocument(session).toJson());
    }

    // ---- Display only. The functions below read the state the acquisition code keeps and show it;
    // they change none of it and call nothing in that code.
    static void showPill(StatusPill* pill, const PillState& state) {
        pill->setState(state.tone, state.text, state.tip, state.prominent);
        pill->setVisible(!state.text.isEmpty());
    }

    void applyTheme(const UiTheme& theme) {
        uiThemeInUse() = theme;
        // The style sheet is taken off first: while one is set, each widget keeps the palette it had
        // before, and a new palette would not reach the parts the sheet leaves to it.
        setStyleSheet(QString());
        setPalette(theme.palette());
        setStyleSheet(theme.styleSheet());
        applyChartTheme(theme, chartView, rtAxX, rtAxY, rtSeries);
        dataPanels->applyTheme();
        for (QWidget* painted : findChildren<QWidget*>()) painted->update();
    }

    // A screen with less room than the default size gets a window that fits on it, so that the status
    // bar and the lower groups are not left below the screen's edge.
    void fitToScreen() {
        const QScreen* monitor = screen();
        if (!monitor) return;
        const QMargins frame = windowHandle() ? windowHandle()->frameMargins() : QMargins();
        const QSize room = monitor->availableGeometry().size() - QSize(frame.left() + frame.right(), frame.top() + frame.bottom());
        const QSize fitted(std::max(minimumWidth(), std::min(width(), room.width())), std::max(minimumHeight(), std::min(height(), room.height())));
        if (fitted == size()) return;
        resize(fitted);
        move(monitor->availableGeometry().topLeft());
    }

    // The chart leads while the logs are shown; the Data and Review tabs get the room their tables need.
    // The same proportion is kept when the window is resized.
    void applyTabSplit() {
        const int tabs = int(1000 * display.tabShare[display.tabs->currentIndex() == 0 ? 0 : 1]);
        display.split->setStretchFactor(0, 1000 - tabs); display.split->setStretchFactor(1, tabs);
        display.split->setSizes({1000 - tabs, tabs});
    }

    void refreshDataDisplay() {
        showPill(display.data, dataPanels->pillState());
        const int waiting = dataPanels->reviewsWaiting();
        display.tabs->setTabText(2, waiting > 0 ? QString("Review (%1)").arg(waiting) : QString("Review"));
    }

    void refreshStatusDisplay() {
        ControllerView view;
        view.backendRunning = laserProcess->state() == QProcess::Running;
        view.captureFault = backendCaptureFault;
        view.laserOn = laserOn; view.laserUncertain = laserStateUncertain; view.laserCommandBusy = laserCommandBusy;
        view.powerInForce = powerInForce ? powerLevelString(*powerInForce) : QString();
        view.laserReadBack = display.laserReadBack;
        view.scanActive = scanActive; view.paused = paused; view.scanMode = currentScanMode; view.savedPoints = lastCompletedPoint;
        // How a scan ended is judged once per session, the first time it is seen not running: from its
        // folder (failure.txt of an abort, cancel.txt of a stop) and from the way the motor program left.
        // Once, because a later Stop or the closing of the window writes cancel.txt into the same folder
        // long after a scan that ran to its end. A start that got no folder is no scan.
        bool scanEnded = false;
        if (scanActive) display.lastScanEnd = ControllerView::ScanEnd::None;
        else if (sessionId != display.sessionJudged) {
            display.sessionJudged = sessionId;
            scanEnded = QFileInfo(sessionDir).isDir();
            const bool motorDone = ramanProcess->error() != QProcess::FailedToStart && ramanProcess->exitStatus() == QProcess::NormalExit &&
                                   ramanProcess->exitCode() == 0;
            display.lastScanEnd = !scanEnded ? ControllerView::ScanEnd::None
                                : QFile::exists(sessionDir + "/failure.txt") ? ControllerView::ScanEnd::Failed
                                : QFile::exists(sessionDir + "/cancel.txt") ? ControllerView::ScanEnd::Stopped
                                : motorDone ? ControllerView::ScanEnd::Finished : ControllerView::ScanEnd::Failed;
        }
        view.lastScanEnd = display.lastScanEnd;
        showPill(display.backend, backendPillState(view));
        showPill(display.laser, laserPillState(view));
        showPill(display.scan, scanPillState(view));
        // While the scan ran, the chart title said LIVE. Once it has ended the title says so, and a scan
        // that saved no point does not leave the curve from before it looking like one of its own.
        if (scanEnded) {
            const QString end = display.lastScanEnd == ControllerView::ScanEnd::Finished ? "finished"
                              : display.lastScanEnd == ControllerView::ScanEnd::Stopped ? "stopped" : "failed";
            if (lastCompletedPoint > 0)
                rtChart->setTitle(QString("%1 - last saved point %2%3 (scan %4)").arg(currentScanMode).arg(lastCompletedPoint)
                                  .arg(currentScanMode == "2d" ? QString() : QString("/%1").arg(kLineScanPointCount)).arg(end));
            else
                rtChart->setTitle(QString("%1 scan %2 - no point saved%3").arg(currentScanMode, end,
                                  rtSeries->count() > 0 ? QString("; the curve shown is not from this scan") : QString()));
        }
        // The laser counts as a hazard whenever it is on or its state is not known for certain.
        const bool laserHazard = laserOn || laserStateUncertain || laserCommandBusy;
        display.hazard->setActive(laserHazard);
        display.laserGroup->setAlert(laserHazard);
        setStyleProperty(display.laserButton, "laser", laserStateUncertain ? "unconfirmed" : laserOn ? "on" : "off");
        setStyleProperty(display.stopButton, "urgent", scanActive);
        setStyleProperty(display.pauseButton, "engaged", scanActive && paused);
        // The dark that a scan or single capture started now would be paired with. It cannot change
        // while one is acquiring, so its folder is not read then.
        if (!scanActive && !isCollecting) {
            display.nextDarkFile = darkForNextCapture();
            const PillState dark = nextDarkCaption(display.nextDarkFile, backendSimulates(startEnvironment(laserProcess)), QDate::currentDate());
            display.nextDark->setText(dark.text, dark.tone);
            display.nextDark->setToolTip(dark.tip);
        }
        // The brightest buttons ("primary") are the next step: Laser ON while the laser is confirmed
        // off; once it is confirmed on and nothing runs, Capture Dark while the next scan would have no
        // dark of its kind, else the two scans and Capture Spectrum, once the required fields are filled
        // in. Colour only: whether a click is accepted stays with the code each button starts.
        const bool backendUsable = laserProcess->state() == QProcess::Running && !backendCaptureFault;
        const bool ready = backendUsable && laserOn && !laserStateUncertain && !laserCommandBusy && !isCollecting && !scanActive &&
                           !monitorActive && ramanProcess->state() == QProcess::NotRunning;
        const bool darkFirst = ready && display.nextDarkFile.isNull();
        const bool fieldsFilled = !sampleIdEdit->text().trimmed().isEmpty() && !operatorEdit->text().trimmed().isEmpty() &&
                                  !locationEdit->text().trimmed().isEmpty();
        const auto role = [](bool primary) { return primary ? QVariant("primary") : QVariant(); };
        setStyleProperty(display.laserButton, "role", role(backendUsable && !laserOn && !laserStateUncertain && !laserCommandBusy));
        setStyleProperty(display.darkButton, "role", role(darkFirst));
        for (QPushButton* next : {display.zScanButton, display.lineScanButton, display.captureButton})
            setStyleProperty(next, "role", role(ready && !darkFirst && fieldsFilled));
        // The data layer registers new points when a scan or a single capture has ended. What it starts
        // by itself keeps clear of a scan, a capture and a laser command that are under way.
        const bool singleCaptureEnded = !isCollecting && singleCaptureDir != display.singleCaptureSeen;
        if (singleCaptureEnded) display.singleCaptureSeen = singleCaptureDir;
        if (scanEnded || singleCaptureEnded) dataPanels->captureFinished();
        dataPanels->setAcquisitionBusy(scanActive || isCollecting || laserCommandBusy || ramanProcess->state() != QProcess::NotRunning);
    }

    // The lines the controller appended to one of its two logs since the last call become the "last event" line.
    void noteLogLines(QTextEdit* log) {
        int& seen = log == laserOutput ? display.laserLinesSeen : display.scanLinesSeen;
        const EventContext context{currentScanMode, lastCompletedPoint, scanCancelled};
        for (QTextBlock line = log->document()->findBlockByNumber(seen); line.isValid(); line = line.next()) {
            // The last line may still be empty: the text of an appended line arrives after its line break.
            if (line.text().isEmpty() && !line.next().isValid()) break;
            ++seen;
            if (const auto event = eventFromLogLine(line.text(), context))
                display.lastEvent->setEvent(event->tone, QTime::currentTime().toString("HH:mm:ss"), event->text);
        }
    }

    void appendLaserLog(const QString &msg) {
        QString timeStr = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
        QString line = QString("[%1] %2").arg(timeStr, msg);
        laserOutput->append(line);
        if (laserTxtFile.isOpen()) { QTextStream out(&laserTxtFile); out << line << "\n"; out.flush(); }
    }

    void clearLaserLogFile() {
        const QString path = laserTxtFile.fileName();
        if (laserTxtFile.isOpen()) laserTxtFile.close();
        QFile f(path);
        if (f.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) { f.close(); laserOutput->append("[laser_log.txt cleared]"); }
        else laserOutput->append("[Failed to clear laser_log.txt]");
        laserTxtFile.setFileName(path);
        laserTxtFile.open(QIODevice::Append | QIODevice::Text);
    }

    QString snapshotCurrentLogToNewFile() {
        const QString srcPath = laserTxtFile.fileName();
        if (srcPath.isEmpty()) return QString();
        const bool wasOpen = laserTxtFile.isOpen();
        if (wasOpen) { laserTxtFile.flush(); laserTxtFile.close(); }
        QFileInfo info(srcPath);
        const QString dstPath = info.absolutePath() + QString("/laser_log_%1.txt").arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss"));
        bool ok = QFile::copy(srcPath, dstPath);
        if (!ok) {
            QFile in(srcPath);
            if (in.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QFile out(dstPath);
                if (out.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) { QByteArray data = in.readAll(); if (out.write(data) == data.size()) ok = true; out.close(); }
                in.close();
            }
        }
        laserTxtFile.setFileName(srcPath);
        if (wasOpen) laserTxtFile.open(QIODevice::Append | QIODevice::Text);
        return ok ? dstPath : QString();
    }

    void stopRamanDataCollection() {
        lineAxisCombo->setEnabled(true);
        setOperatorFieldsLocked(false);
        scanActive = false;
        scanCancelled = true;
    }

    void stopMotorScan() {
        scanCancelled = true; scanActive = false;
        if (!sessionDir.isEmpty()) AcquisitionProtocol::publish(sessionDir + "/cancel.txt", "STOP\n");
        if (ramanProcess && ramanProcess->state() != QProcess::NotRunning) {
            // Kinesis closes three device connections serially; allow normal cleanup.
            if (!ramanProcess->waitForFinished(8000)) {
                ramanOutput->append("[Warning] Motor did not exit after cancellation; forcing process exit. Check controller status.");
                ramanProcess->kill(); ramanProcess->waitForFinished(2000);
            }
        }
    }

    bool replyToPoint(quint64 point, const QString& status) {
        const auto bytes = QString("ACK %1 %2 %3 %4\n").arg(sessionId).arg(point).arg(status)
                           .arg(QDateTime::currentMSecsSinceEpoch()).toUtf8();
        return AcquisitionProtocol::publish(sessionDir + "/response.txt", bytes);
    }

    void failScan(const QString& reason) {
        AcquisitionProtocol::publish(sessionDir + "/failure.txt", reason.toUtf8());
        appendLaserLog("[Scan failed] " + reason);
        ramanOutput->append("[Scan aborted] " + reason + ". Motor must not advance. Laser remains under manual control.");
        stopMotorScan();
    }

    void stopFocusMonitor() {
        monitorActive = false;
        if (rtTimer) rtTimer->stop();
        if (monitorButton->isChecked()) monitorButton->setChecked(false);
        monitorButton->setText("Monitor: OFF");
    }

    void captureFocusFrame() {
        if (!monitorActive) return;
        if (!laserOn || isCollecting || laserCommandBusy || scanActive || backendCaptureFault ||
            ramanProcess->state() != QProcess::NotRunning) { stopFocusMonitor(); return; }
        QScopedValueRollback<bool> guard(isCollecting, true);
        pendingMonitorId = "monitor_" + QUuid::createUuid().toString(QUuid::WithoutBraces);
        monitorReply.clear();
        QVector<int> spectrum; QString error;
        const bool ok = collectRamanData(pendingMonitorId, spectrum, error, true);
        pendingMonitorId.clear(); monitorReply.clear();
        if (!ok) {
            stopFocusMonitor();
            rtChart->setTitle("Focus preview STOPPED - capture failed; displayed curve may be old");
            ramanOutput->append("[Focus Monitor Error] " + error); return;
        }
        if (!monitorActive) { rtChart->setTitle("Focus preview stopped - last displayed frame"); return; }
        ++monitorFrameCount;
        displaySpectrum(spectrum);
        rtChart->setTitle("Focus preview (NOT saved) - " + QDateTime::currentDateTime().toString("HH:mm:ss.zzz"));
        rtTimer->start(50); // Only request another frame after the previous one completed.
    }

    bool collectRamanData(const QString& captureId, QVector<int>& spectrum, QString& error, bool preview = false) {
        const QString base = laserProcess->workingDirectory();
        if (backendCaptureFault || laserProcess->state() != QProcess::Running) {
            error = "Backend unavailable/faulted"; return false;
        }
        // Never overwrite an unconsumed command or reuse an identifier.
        if (QFile::exists(base + "/command.txt") ||
            !AcquisitionProtocol::publish(base + "/command.txt", ((preview ? "M " : "S ") + captureId + "\n").toUtf8())) {
            error = "Backend command pending or write failed"; backendCaptureFault = true; return false;
        }
        QElapsedTimer elapsed; elapsed.start();
#ifdef HANDSHAKE_TESTING
        const int captureTimeoutMs = 1500;
#else
        const int captureTimeoutMs = 15000;
#endif
        const int maxReadAttempts = 3;
        const int readRetryDelayMs = 100;
        int readAttempts = 0;
        qint64 nextReadAt = 0;
        QString lastReadError;
        while (elapsed.elapsed() < captureTimeoutMs) {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
            if (preview && !monitorReply.isEmpty()) {
                if (!AcquisitionProtocol::parseSpectrum(monitorReply, captureId, kNumPixels, spectrum, error)) break;
                return true;
            }
            QFile result(base + "/capture_results/" + captureId + ".txt");
            if (!preview && result.exists() && elapsed.elapsed() >= nextReadAt) {
                ++readAttempts;
                QByteArray contents;
                const bool opened = result.open(QIODevice::ReadOnly);
                if (opened) contents = result.readAll();
                if (!opened || result.error() != QFileDevice::NoError) {
                    lastReadError = QString("Cannot read capture result (attempt %1/%2): %3; file: %4")
                        .arg(readAttempts).arg(maxReadAttempts).arg(result.errorString(), result.fileName());
                    result.close();
                    appendLaserLog("[Capture read] " + lastReadError);
                    if (readAttempts >= maxReadAttempts) { error = lastReadError; break; }
                    // Retry only this file, never send another acquisition command.
                    nextReadAt = elapsed.elapsed() + readRetryDelayMs;
                } else {
                    result.close();
                    if (!AcquisitionProtocol::parseSpectrum(contents, captureId, kNumPixels, spectrum, error)) break;
                    if (readAttempts > 1)
                        appendLaserLog(QString("[Capture read recovered] %1; attempt %2/%3")
                            .arg(captureId).arg(readAttempts).arg(maxReadAttempts));
                    return true;
                }
            }
            if (laserProcess->state() != QProcess::Running) { error = "Backend exited during capture"; break; }
            QThread::msleep(20);
        }
        if (error.isEmpty()) error = QString("Capture timed out (%1 ms); no blind retry and no success ACK").arg(captureTimeoutMs)
            + (lastReadError.isEmpty() ? QString() : "; " + lastReadError);
        backendCaptureFault = true;
        return false;
    }

    void handleScanPoint() {
        if (isCollecting || laserCommandBusy || !scanActive || scanCancelled ||
            !laserOn || ramanProcess->state() != QProcess::Running) return;
        QFile request(sessionDir + "/request.txt");
        if (!request.open(QIODevice::ReadOnly)) return;
        AcquisitionProtocol::Point point;
        const auto bytes = request.readAll(); request.close();
        if (!AcquisitionProtocol::parsePoint(bytes, sessionId, point)) {
            failScan("Invalid point request or wrong session"); return;
        }
        if (point.id != lastCompletedPoint && point.id != lastCompletedPoint + 1) {
            failScan("Unexpected point sequence"); return;
        }
        if (paused) {
            if (!replyToPoint(point.id, "PAUSED")) failScan("Cannot publish pause heartbeat");
            return;
        }
        if (point.id == lastCompletedPoint) {
            if (!replyToPoint(point.id, "OK")) failScan("Cannot publish saved-point ACK");
            return;
        }
        QScopedValueRollback<bool> captureGuard(isCollecting, true);
        if (!replyToPoint(point.id, "HOLD")) { failScan("Cannot publish capture heartbeat"); return; }
        const QString captureId = sessionId + "_" + QString::number(point.id);
        const QString started = QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs);
        QElapsedTimer duration; duration.start();
        QVector<int> spectrum; QString error;
        if (!collectRamanData(captureId, spectrum, error)) {
            replyToPoint(point.id, "FAIL"); failScan(error); return;
        }
        if (scanCancelled || !scanActive || ramanProcess->state() != QProcess::Running) {
            appendLaserLog("[Capture discarded from scan] Scan stopped; raw backend result retained: " + captureId);
            return;
        }
        QJsonArray pixels;
        for (int value : spectrum) pixels.append(value);
        QJsonObject record{
            {"scan_mode", currentScanMode},
            {"protocol", 2}, {"session_id", sessionId}, {"point_id", static_cast<qint64>(point.id)},
            {"capture_id", captureId}, {"started_utc", started},
            {"completed_utc", QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs)},
            {"capture_elapsed_ms", duration.elapsed()}, {"status", "OK"},
            {"controller_x_steps", point.x}, {"controller_y_steps", point.y}, {"controller_z_steps", point.z},
            {"pixel_count", spectrum.size()}, {"intensity", pixels}
        };
        record.insert("capture", scanCapture);
        const QString file = sessionDir + QString("/point_%1.json").arg(point.id, 4, 10, QChar('0'));
        if (!AcquisitionProtocol::publish(file, QJsonDocument(record).toJson())) {
            replyToPoint(point.id, "FAIL"); failScan("Cannot save point spectrum"); return;
        }
        // Keep the legacy hexadecimal Image Data line for existing TXT readers.
        QString txt;
        QTextStream out(&txt);
        out << "# Scan mode: " << currentScanMode << "\n# Session: " << sessionId
            << "\n# Point: " << point.id << "\n# Completed UTC: " << record["completed_utc"].toString()
            << "\n# Controller XYZ steps: " << point.x << " " << point.y << " " << point.z
            << "\n# Pixels: " << spectrum.size() << "\nImage Data";
        for (int value : spectrum) out << " " << QString::number(value, 16).toUpper().rightJustified(4, '0');
        out << "\n";
        out.flush();
        // Atomically replace the combined log before acknowledging this point.
        const QString combinedPath = sessionDir + "/laser_log_combined.txt";
        QByteArray combined = combinedScanTxt;
        combined += txt.toUtf8();
        combined += "Stop Capture\n\n";
        if (!AcquisitionProtocol::publish(combinedPath, combined)) {
            replyToPoint(point.id, "FAIL"); failScan("Cannot save combined TXT; point not acknowledged"); return;
        }
        combinedScanTxt = combined;
        lastCompletedPoint = point.id;
        displaySpectrum(spectrum);
        rtChart->setTitle(QString("%1 - saved point %2%3 (LIVE)").arg(currentScanMode).arg(point.id)
                         .arg(currentScanMode == "2d" ? "" : "/13"));
        appendLaserLog(QString("[Point saved] run=%1 point=%2 pixels=%3 elapsed_ms=%4")
                       .arg(sessionId).arg(point.id).arg(spectrum.size()).arg(duration.elapsed()));
        // Pause during exposure saves this point but holds the motor until Resume.
        if (!replyToPoint(point.id, paused ? "PAUSED" : "OK")) failScan("Cannot publish point ACK");
    }

    // Hamamatsu SampleApl menu: 6 -> USB2_setLDPowerEnable; 4 -> USB2_setLDPower;
    // 5 -> USB2_getLDPowerEnable. Each setter consumes its parameter separately.
    bool setLaserEnabledAndConfirm(bool enable) {
        const QString ackFile = "command_completed.txt";
        laserReplyBuffer.clear();
        if (!sendLaserCommand("6", ackFile) ||
            !sendLaserCommand(enable ? "1" : "0", ackFile)) return false;
        if (enable) {
            if (!sendLaserCommand("4", ackFile) ||
                !sendLaserCommand(powerCommandForLevel(sentPower = selectedPower), ackFile)) return false;
        }
        // The file acknowledges command consumption, not USB success. Read back
        // enable state from the device before permitting a scan.
        if (!sendLaserCommand("5", ackFile)) return false;
        const QRegularExpression statePattern("LD Power Enable\\s*:\\s*0x([0-9a-fA-F]+)");
        QElapsedTimer timer;
        timer.start();
        while (timer.elapsed() < 4000) {
            QCoreApplication::processEvents();
            if (laserProcess->state() != QProcess::Running ||
                laserReplyBuffer.contains("Error code", Qt::CaseInsensitive)) return false;
            const auto match = statePattern.match(laserReplyBuffer);
            if (match.hasMatch()) {
                bool ok = false;
                const auto actual = match.captured(1).toUInt(&ok, 16);
                return ok && ((actual == 1) == enable);
            }
            QThread::msleep(20);
        }
        appendLaserLog("[Laser] Timed out reading LD Power Enable from backend.");
        return false;
    }

    bool sendLaserCommand(const QString &cmd, const QString &ackFileName = "command_completed.txt") {
        const QString basePath = laserProcess->workingDirectory();
        QString commandFilePath = basePath + "/command.txt";
        QString completedFilePath = basePath + "/" + ackFileName;
        QFile completedFile(completedFilePath);
        if (completedFile.exists()) completedFile.remove();
        if (QFile::exists(commandFilePath) || !AcquisitionProtocol::publish(commandFilePath, cmd.toUtf8())) {
            appendLaserLog("[Error] Pending backend command or command write failed."); return false;
        }
        QElapsedTimer timer; timer.start();
        while (timer.elapsed() < 4000) {
            QCoreApplication::processEvents();
            if (QFile::exists(completedFilePath)) {
                QFile doneFile(completedFilePath);
                if (doneFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
                    QString response = doneFile.readAll(); doneFile.close();
                    if (response.contains("done")) { QFile::remove(completedFilePath); return true; }
                }
            }
            QThread::msleep(100);
        }
        appendLaserLog("[Timeout waiting for command processing]");
        return false;
    }

    QVector<QPointF> spectrumToShiftCurve_RT(const QVector<int>& intensity) {
        QVector<QPointF> pts; int n = intensity.size();
        if (n < 10) return pts;
        int maxPoints = std::min(n, kNumPixels); pts.reserve(maxPoints);
        for (int i = 0; i < maxPoints; ++i) pts.append(QPointF(kRamanShift[i], intensity[i]));
        return pts;
    }

    bool readLastImageDataHexAsInts_RT(const QString& path, QVector<int>& out) {
        QFile file(path); if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return false;
        QTextStream in(&file); QString lastLine;
        while (!in.atEnd()) { const QString line = in.readLine(); if (line.contains("Image Data")) lastLine = line; }
        file.close(); if (lastLine.isEmpty()) return false;
        const int idx = lastLine.indexOf("Image Data");
        QStringList hexList = lastLine.mid(idx + int(strlen("Image Data"))).split(" ", Qt::SkipEmptyParts);
        out.clear(); out.reserve(hexList.size());
        for (const QString& hex : hexList) { bool ok = false; int value = hex.toInt(&ok, 16); if (ok) out.push_back(value); }
        return !out.isEmpty();
    }

    bool parseImageDataLineToInts(const QString& line, QVector<int>& out) const {
        const int idx = line.indexOf("Image Data"); if (idx < 0) return false;
        QStringList hexList = line.mid(idx + int(strlen("Image Data"))).split(" ", Qt::SkipEmptyParts);
        out.clear(); out.reserve(hexList.size());
        for (const QString& hex : hexList) { bool ok = false; int value = hex.toInt(&ok, 16); if (ok) out.push_back(value); }
        return !out.isEmpty();
    }

    QString saveDarkMeasurementToTxt(const QVector<int>& spectrum) const {
        const QString dir = ramanHome() + "/dark_measurements";
        if (!QDir().mkpath(dir)) return QString();
        const QString base = dir + QString("/dark_%1").arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss_zzz"));
        QString path = base + ".txt";
        for (int suffix = 1; QFile::exists(path); ++suffix) path = base + "_" + QString::number(suffix) + ".txt";
        QFile file(path); if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::NewOnly)) return QString();
        QTextStream out(&file);
        out << "# Dark Measurement\n# Timestamp: " << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz")
            << "\n# Points: " << spectrum.size() << "\nindex\traman_shift_cm-1\tintensity\n";
        const int n = std::min<int>(static_cast<int>(spectrum.size()), kNumPixels);
        for (int i = 0; i < n; ++i) out << i << "\t" << QString::number(kRamanShift[i], 'f', 8) << "\t" << spectrum[i] << "\n";
        out.flush();
        const bool saved = out.status() == QTextStream::Ok && file.flush();
        file.close();
        if (!saved) { file.remove(); return QString(); }
        return path;
    }

    // dark_<stamp>.json beside a saved dark_<stamp>.txt (lead decision D1): whether the helper programs
    // simulated when the dark was taken, so that it is only ever paired with spectra of the same kind.
    bool publishDarkRecord(const QString& darkTxt, const QString& capturedUtc) const {
        const QJsonObject record{
            {"schema", "raman-dark-description/1"}, {"dark_file", QFileInfo(darkTxt).fileName()}, {"captured_utc", capturedUtc},
            {"simulated", simulatedFlags()}, {"instrument", instrumentInfo},
            {"software", QJsonObject{{"name", kSoftwareName}, {"version", kSoftwareVersion}}}
        };
        return AcquisitionProtocol::publish(darkRecordPath(darkTxt), QJsonDocument(record).toJson());
    }

    // A dark spectrum: dark_<stamp>.txt exactly as it has always been written, then its .json. Both or
    // neither: a .txt left without its .json would count as a real dark. Empty when it is not saved.
    QString saveDark(const QVector<int>& spectrum, const QString& capturedUtc) {
        const QString path = saveDarkMeasurementToTxt(spectrum);
        if (path.isEmpty() || publishDarkRecord(path, capturedUtc)) return path;
        if (!QFile::remove(path))
            ramanOutput->append("[Dark Error] " + path + " has no .json and could not be removed: delete it, "
                                "or it is taken for a real dark.");
        return QString();
    }

    void captureDarkMeasurement() {
        if (monitorActive) { ramanOutput->append("[Dark] Stop Focus Monitor first."); return; }
        if (isCollecting || laserCommandBusy || scanActive || ramanProcess->state() != QProcess::NotRunning) {
            ramanOutput->append("[Dark] Stop the scan and wait for acquisition to finish first."); return;
        }
        if (backendCaptureFault) { ramanOutput->append("[Dark] Capture fault: restart after confirming Laser OFF."); return; }
        QScopedValueRollback<bool> guard(isCollecting, true);
        ramanOutput->append("[Dark] Acquiring a NEW spectrum. Ensure the optical path is blocked / covered.");
        const QString id = "dark_" + QUuid::createUuid().toString(QUuid::WithoutBraces);
        QVector<int> spectrum; QString error;
        if (!collectRamanData(id, spectrum, error)) { ramanOutput->append("[Dark Error] " + error); return; }
        const QString path = saveDark(spectrum, QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs));
        ramanOutput->append(path.isEmpty() ? "[Dark Error] Save failed." : "[Dark] Saved: " + path);
    }

    // One saved spectrum at the current position (data_layer/PROTOCOL.md section 2.4). The motor
    // program is not started: nothing is requested or acknowledged, and the stage position is not
    // known, so the three step values are null. The scan state (sessionDir, sessionId) is left alone.
    void captureSingleSpectrum() {
        if (!requiredFieldsFilled("[Capture]")) return;
        if (monitorActive) { ramanOutput->append("[Capture] Stop Focus Monitor first."); return; }
        if (isCollecting || laserCommandBusy || scanActive || ramanProcess->state() != QProcess::NotRunning) {
            ramanOutput->append("[Capture] Stop the scan and wait for acquisition to finish first."); return;
        }
        if (backendCaptureFault) { ramanOutput->append("[Capture] Capture fault: restart after confirming Laser OFF."); return; }
        // Unlike a dark, a single capture creates its session folder first: do not leave one that cannot get a spectrum.
        if (laserProcess->state() != QProcess::Running) { ramanOutput->append("[Capture] Laser backend is not running."); return; }
        if (!laserOn || laserStateUncertain) { ramanOutput->append("[Capture] Turn on the laser and confirm its status first."); return; }
        QScopedValueRollback<bool> guard(isCollecting, true);
        setOperatorFieldsLocked(true);
        const auto unlockFields = qScopeGuard([this] { setOperatorFieldsLocked(false); });
        const QString id = QUuid::createUuid().toString(QUuid::WithoutBraces);
        const QString root = ramanHome() + "/scan_sessions";
        const QString base = "single_" + QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss_zzz");
        if (!QDir().mkpath(root)) { ramanOutput->append("[Capture] Cannot create data directory."); return; }
        QString folder = base;
        for (int suffix = 1; QDir(root).exists(folder); ++suffix) folder = base + "_" + QString::number(suffix);
        if (!QDir(root).mkdir(folder)) { ramanOutput->append("[Capture] Cannot create unique data directory."); return; }
        const QString dir = root + "/" + folder;
        const QJsonObject capture = captureMetadata();
        if (!publishSessionFile(dir, id, "single", capture)) {
            QDir(root).rmdir(folder);
            ramanOutput->append("[Capture] Cannot create session.json."); return;
        }
        singleCaptureDir = dir;
        const auto fail = [this, &dir](const QString& reason) {
            AcquisitionProtocol::publish(dir + "/failure.txt", reason.toUtf8());
            appendLaserLog("[Single capture failed] " + reason);
            rtChart->setTitle("Single capture FAILED - the displayed curve is not this capture");
            ramanOutput->append("[Capture Error] " + reason + ". No spectrum saved.");
        };
        const QString captureId = "single_" + id;
        const QString started = QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs);
        QElapsedTimer duration; duration.start();
        QVector<int> spectrum; QString error;
        if (!collectRamanData(captureId, spectrum, error)) { fail(error); return; }
        QJsonArray pixels;
        for (int value : spectrum) pixels.append(value);
        const QJsonObject record{
            {"scan_mode", "single"},
            {"protocol", 2}, {"session_id", id}, {"point_id", 1},
            {"capture_id", captureId}, {"started_utc", started},
            {"completed_utc", QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs)},
            {"capture_elapsed_ms", duration.elapsed()}, {"status", "OK"},
            {"controller_x_steps", QJsonValue()}, {"controller_y_steps", QJsonValue()}, {"controller_z_steps", QJsonValue()},
            {"pixel_count", spectrum.size()}, {"intensity", pixels}, {"capture", capture}
        };
        if (!AcquisitionProtocol::publish(dir + "/point_0001.json", QJsonDocument(record).toJson())) {
            fail("Cannot save point spectrum"); return;
        }
        displaySpectrum(spectrum);
        rtChart->setTitle("single - saved spectrum (" + folder + ")");
        appendLaserLog(QString("[Single capture saved] run=%1 pixels=%2 elapsed_ms=%3")
                       .arg(id).arg(spectrum.size()).arg(duration.elapsed()));
        ramanOutput->append("[Capture] Saved: " + dir);
    }
};

#include "main.moc"

#ifndef HANDSHAKE_TESTING
int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    QLockFile controllerLock(ramanHome() + "/controller.lock");
    if (!controllerLock.tryLock(100)) {
        const LockRefusal refusal = lockRefusal(false, controllerLock.error(), ramanHome() + "/controller.lock");
        QMessageBox::warning(nullptr, refusal.title, refusal.text);
        return 1;
    }
    OriginalControllerLock originalControllerLock;
    if (!originalControllerLock.acquire(ramanHome())) {
        const LockRefusal refusal = lockRefusal(true, originalControllerLock.error(), originalControllerLock.filePath());
        QMessageBox::warning(nullptr, refusal.title, refusal.text);
        return 1;
    }
    // Names the store in which Operator and Location are remembered (MainWindow::remembersOperatorFields).
    // Set only after the locks are taken, so that they are taken exactly as the original program takes its own.
    QCoreApplication::setOrganizationName("PortableRaman");
    QCoreApplication::setApplicationName(kSoftwareName);
    useUiBaseStyle();
    MainWindow window;
    window.show();
    return app.exec();
}
#endif
